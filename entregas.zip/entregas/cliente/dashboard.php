<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';
requireRole('cliente');

$user = currentUser();
$stmt = $pdo->prepare('SELECT p.*, u.name AS repartidor FROM packages p LEFT JOIN users u ON p.assigned_to = u.id WHERE p.customer_id = :id ORDER BY p.created_at DESC');
$stmt->execute(['id' => $user['id']]);
$packages = $stmt->fetchAll();
$title = 'Panel cliente';
require __DIR__ . '/../includes/header.php';
?>
<div class="d-flex">
    <?php require __DIR__ . '/../includes/sidebar.php'; ?>
    <div class="flex-grow-1 p-4">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h1 class="h3 mb-1 text-primary"><i class="fas fa-user-circle me-2"></i>Hola, <?php echo esc($user['name']); ?></h1>
                <p class="text-muted mb-0">Revisa el estado de tus envíos.</p>
            </div>
        </div>
        <div class="card shadow-sm">
            <div class="card-header bg-primary text-white">
                <h5 class="card-title mb-0"><i class="fas fa-box"></i> Mis paquetes</h5>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0">
                        <thead class="table-light">
                            <tr>
                                <th><i class="fas fa-hashtag text-primary"></i> Código</th>
                                <th><i class="fas fa-map-marker text-primary"></i> Destino</th>
                                <th><i class="fas fa-truck text-primary"></i> Repartidor</th>
                                <th><i class="fas fa-info-circle text-primary"></i> Estado</th>
                                <th><i class="fas fa-dollar-sign text-primary"></i> Tarifa</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php if ($packages): foreach ($packages as $pkg): ?>
                            <tr>
                                <td><span class="badge bg-secondary"><?php echo esc($pkg['code']); ?></span></td>
                                <td><?php echo esc($pkg['destination']); ?></td>
                                <td><?php echo esc($pkg['repartidor'] ?? 'Sin asignar'); ?></td>
                                <td>
                                    <span class="badge 
                                    <?php 
                                    echo match($pkg['status']) {
                                        'recibido' => 'bg-warning',
                                        'en_transito' => 'bg-info',
                                        'entregado' => 'bg-success',
                                        default => 'bg-secondary'
                                    };
                                    ?>">
                                    <?php echo esc($pkg['status']); ?>
                                    </span>
                                </td>
                                <td class="text-success fw-bold">$<?php echo number_format($pkg['delivery_fee'], 2); ?></td>
                            </tr>
                        <?php endforeach; else: ?>
                            <tr>
                                <td colspan="5" class="text-center py-4">
                                    <i class="fas fa-inbox fa-2x text-muted mb-2"></i>
                                    <br>No tienes paquetes registrados.
                                </td>
                            </tr>
                        <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php require __DIR__ . '/../includes/footer.php';
