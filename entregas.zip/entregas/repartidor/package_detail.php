<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';
requireRole('repartidor');

$user = currentUser();
function statusLabel($status) {
    $labels = [
        'recibido' => 'Recibido',
        'en_transito' => 'En tránsito',
        'entregado' => 'Entregado'
    ];
    return $labels[$status] ?? $status;
}
$id = $_GET['id'] ?? null;
if (!$id) {
    redirect('/entregas/repartidor/packages.php');
}

$stmt = $pdo->prepare('SELECT p.*, u.name AS cliente FROM packages p LEFT JOIN users u ON p.customer_id = u.id WHERE p.id = :id AND p.assigned_to = :user_id LIMIT 1');
$stmt->execute(['id' => $id, 'user_id' => $user['id']]);
$package = $stmt->fetch();
if (!$package) {
    http_response_code(404);
    echo 'Paquete no encontrado.';
    exit;
}

$message = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['status'])) {
    $newStatus = $_POST['status'];
    if (in_array($newStatus, ['recibido', 'en_transito', 'entregado'])) {
        $stmt = $pdo->prepare('UPDATE packages SET status = :status WHERE id = :id');
        $stmt->execute(['status' => $newStatus, 'id' => $id]);
        $message = 'Estado actualizado correctamente.';
        $package['status'] = $newStatus;
        
        // Trigger check animation for status updates
        echo '<script>$(document).ready(function() { setTimeout(function() { showCheckAnimation({message: "¡Estado actualizado!", duration: 2000, type: "toast"}); }, 300); });</script>';
    }
}

$title = 'Detalle del paquete';
require __DIR__ . '/../includes/header.php';
?>
<div class="d-flex">
    <?php require __DIR__ . '/../includes/sidebar.php'; ?>
    <div class="flex-grow-1 p-4">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h1 class="h3 mb-1 text-primary"><i class="fas fa-box-open me-2"></i>Detalle del paquete: <span class="badge bg-primary"><?php echo esc($package['code']); ?></span></h1>
                <p class="text-muted mb-0">Información completa y gestión de estado del paquete.</p>
            </div>
            <a href="packages.php" class="btn btn-outline-secondary btn-lg">
                <i class="fas fa-arrow-left me-2"></i>Volver
            </a>
        </div>
        <?php if ($message): ?>
            <div class="alert alert-success"><?php echo esc($message); ?></div>
        <?php endif; ?>
        <div class="row g-4">
            <div class="col-lg-8">
                <div class="card shadow-sm">
                    <div class="card-header bg-primary text-white">
                        <h5 class="card-title mb-0"><i class="fas fa-box"></i> Información del paquete</h5>
                    </div>
                    <div class="card-body">
                        <div class="row g-3">
                            <div class="col-md-6">
                                <div class="d-flex align-items-center">
                                    <i class="fas fa-hashtag text-primary me-2"></i>
                                    <strong>Código:</strong> <span class="badge bg-secondary"><?php echo esc($package['code']); ?></span>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="d-flex align-items-center">
                                    <i class="fas fa-info-circle text-primary me-2"></i>
                                    <strong>Estado:</strong>
                                    <?php
                                    $statusClass = match($package['status']) {
                                        'recibido' => 'bg-warning',
                                        'en_transito' => 'bg-info',
                                        'entregado' => 'bg-success',
                                        default => 'bg-secondary'
                                    };
                                    ?>
                                    <span class="badge <?php echo $statusClass; ?> ms-2"><?php echo statusLabel($package['status']); ?></span>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="d-flex align-items-center">
                                    <i class="fas fa-user text-primary me-2"></i>
                                    <strong>Cliente:</strong> <?php echo esc($package['cliente'] ?? 'N/E'); ?>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="d-flex align-items-center">
                                    <i class="fas fa-dollar-sign text-success me-2"></i>
                                    <strong>Tarifa:</strong> <span class="text-success fw-bold">$<?php echo number_format($package['delivery_fee'], 2); ?></span>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="d-flex align-items-center">
                                    <i class="fas fa-map-marker-alt text-danger me-2"></i>
                                    <strong>Origen:</strong> <?php echo esc($package['origin']); ?>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="d-flex align-items-center">
                                    <i class="fas fa-map-marker text-success me-2"></i>
                                    <strong>Destino:</strong> <?php echo esc($package['destination']); ?>
                                </div>
                            </div>
                            <div class="col-12">
                                <div class="d-flex align-items-start">
                                    <i class="fas fa-file-alt text-primary me-2 mt-1"></i>
                                    <div>
                                        <strong>Descripción:</strong><br>
                                        <p class="mb-0"><?php echo nl2br(esc($package['description'])); ?></p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="d-flex align-items-center">
                                    <i class="fas fa-calendar-plus text-muted me-2"></i>
                                    <strong>Creado:</strong> <?php echo date('d/m/Y H:i', strtotime($package['created_at'])); ?>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="d-flex align-items-center">
                                    <i class="fas fa-calendar-check text-muted me-2"></i>
                                    <strong>Actualizado:</strong> <?php echo date('d/m/Y H:i', strtotime($package['updated_at'])); ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-4">
                <div class="card shadow-sm mb-4">
                    <div class="card-header bg-warning text-dark">
                        <h5 class="card-title mb-0"><i class="fas fa-edit"></i> Cambiar estado</h5>
                    </div>
                    <div class="card-body">
                        <form method="post">
                            <div class="mb-3">
                                <label class="form-label fw-bold">Nuevo estado</label>
                                <select name="status" class="form-select form-select-lg" required>
                                    <option value="recibido" <?php if ($package['status'] === 'recibido') echo 'selected'; ?>>📦 Recibido</option>
                                    <option value="en_transito" <?php if ($package['status'] === 'en_transito') echo 'selected'; ?>>🚚 En tránsito</option>
                                    <option value="entregado" <?php if ($package['status'] === 'entregado') echo 'selected'; ?>>✅ Entregado</option>
                                </select>
                            </div>
                            <button class="btn btn-primary btn-lg w-100" type="submit">
                                <i class="fas fa-save me-2"></i>Actualizar estado
                            </button>
                        </form>
                    </div>
                </div>
                <div class="card shadow-sm">
                    <div class="card-header bg-info text-white">
                        <h5 class="card-title mb-0"><i class="fas fa-map-marker-alt"></i> Ubicación del repartidor</h5>
                    </div>
                    <div class="card-body">
                        <button id="get-location-btn" class="btn btn-outline-primary btn-lg w-100 mb-3">
                            <i class="fas fa-crosshairs me-2"></i>Obtener mi ubicación
                        </button>
                        <div id="location-info" class="alert alert-light border"></div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row mt-4">
            <div class="col-12">
                <div class="card shadow-sm">
                    <div class="card-header bg-success text-white">
                        <h5 class="card-title mb-0"><i class="fas fa-route"></i> Ruta y distancia</h5>
                    </div>
                    <div class="card-body">
                        <div id="distance-info" class="mb-3 alert alert-info"></div>
                        <div class="d-flex justify-content-end mb-3">
                            <a href="https://www.google.com/maps/dir/?api=1&destination=<?php echo urlencode($package['destination'] . ', Chile'); ?>" target="_blank" class="btn btn-success">
                                <i class="fas fa-external-link-alt me-2"></i>Abrir en Google Maps
                            </a>
                        </div>
                        <div id="map" style="height: 400px; width: 100%; border-radius: 0.375rem;" class="border"></div>
                    </div>
                </div>
            </div>
        </div>
       
    </div>
</div>
<script src="https://maps.googleapis.com/maps/api/js?key=YOUR_GOOGLE_MAPS_API_KEY&libraries=geometry"></script>
<script>
function initMap() {
    const originAddress = "<?php echo addslashes($package['origin']); ?>" + ", Chile";
    const destinationAddress = "<?php echo addslashes($package['destination']); ?>" + ", Chile";

    const geocoder = new google.maps.Geocoder();
    const directionsService = new google.maps.DirectionsService();
    const directionsRenderer = new google.maps.DirectionsRenderer();
    const map = new google.maps.Map(document.getElementById('map'), {
        zoom: 7
    });
    directionsRenderer.setMap(map);

    let originLatLng, destinationLatLng;

    // Geocode origin
    geocoder.geocode({ 'address': originAddress }, function(results, status) {
        if (status == google.maps.GeocoderStatus.OK) {
            originLatLng = results[0].geometry.location;
            checkRoute();
        } else {
            document.getElementById('distance-info').innerHTML = 
                '<div class="alert alert-danger">Error al geocodificar origen.</div>';
        }
    });

    // Geocode destination
    geocoder.geocode({ 'address': destinationAddress }, function(results, status) {
        if (status == google.maps.GeocoderStatus.OK) {
            destinationLatLng = results[0].geometry.location;
            checkRoute();
        } else {
            document.getElementById('distance-info').innerHTML = 
                '<div class="alert alert-danger">Error al geocodificar destino.</div>';
        }
    });

    function checkRoute() {
        if (originLatLng && destinationLatLng) {
            const request = {
                origin: originLatLng,
                destination: destinationLatLng,
                travelMode: google.maps.TravelMode.DRIVING
            };
            directionsService.route(request, function(result, status) {
                if (status == google.maps.DirectionsStatus.OK) {
                    directionsRenderer.setDirections(result);
                    const route = result.routes[0];
                    const distance = route.legs[0].distance.text;
                    const duration = route.legs[0].duration.text;
                    document.getElementById('distance-info').innerHTML = 
                        '<i class="fas fa-route text-primary me-2"></i><strong>Distancia:</strong> ' + distance + ' | <i class="fas fa-clock text-warning me-2"></i><strong>Tiempo estimado:</strong> ' + duration;
                } else {
                    document.getElementById('distance-info').innerHTML = 
                        '<div class="alert alert-warning">No se pudo calcular la ruta.</div>';
                }
            });
        }
    }

    // Geolocation button
    document.getElementById('get-location-btn').addEventListener('click', function() {
        if (navigator.geolocation) {
            navigator.geolocation.getCurrentPosition(function(position) {
                const currentLatLng = new google.maps.LatLng(position.coords.latitude, position.coords.longitude);
                document.getElementById('location-info').innerHTML = 
                    '<i class="fas fa-map-marker-alt text-success me-2"></i><strong>Tu ubicación:</strong> ' + position.coords.latitude + ', ' + position.coords.longitude;

                // Add marker for current location
                new google.maps.Marker({
                    position: currentLatLng,
                    map: map,
                    title: 'Tu ubicación',
                    icon: 'http://maps.google.com/mapfiles/ms/icons/blue-dot.png'
                });

                // Calculate distance to destination
                if (destinationLatLng) {
                    const service = new google.maps.DistanceMatrixService();
                    service.getDistanceMatrix({
                        origins: [currentLatLng],
                        destinations: [destinationLatLng],
                        travelMode: google.maps.TravelMode.DRIVING
                    }, function(response, status) {
                        if (status == google.maps.DistanceMatrixStatus.OK) {
                            const dist = response.rows[0].elements[0].distance.text;
                            const dur = response.rows[0].elements[0].duration.text;
                            document.getElementById('location-info').innerHTML += 
                                '<br><i class="fas fa-route text-info me-2"></i><strong>Distancia al destino:</strong> ' + dist + ' | <i class="fas fa-clock text-warning me-2"></i><strong>Tiempo:</strong> ' + dur;
                        } else {
                            document.getElementById('location-info').innerHTML += 
                                '<br><div class="alert alert-warning">No se pudo calcular distancia a destino.</div>';
                        }
                    });
                }
            }, function(error) {
                let errorMessage = 'Error al obtener ubicación.';
                switch(error.code) {
                    case error.PERMISSION_DENIED:
                        errorMessage = 'Permiso de ubicación denegado. Activa la localización en tu navegador.';
                        break;
                    case error.POSITION_UNAVAILABLE:
                        errorMessage = 'Ubicación no disponible.';
                        break;
                    case error.TIMEOUT:
                        errorMessage = 'Tiempo de espera agotado.';
                        break;
                }
                document.getElementById('location-info').innerHTML = 
                    '<div class="alert alert-danger">' + errorMessage + '</div>';
            });
        } else {
            document.getElementById('location-info').innerHTML = 
                '<div class="alert alert-danger">Geolocalización no soportada por este navegador.</div>';
        }
    });
}

window.addEventListener('load', initMap);
</script>
<?php require __DIR__ . '/../includes/footer.php';
