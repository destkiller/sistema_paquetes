<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';
requireRole('repartidor');

$user = currentUser();

// Obtener semana seleccionada o actual
$selectedDate = $_GET['week'] ?? date('Y-m-d');
$startOfWeek = date('Y-m-d', strtotime('monday this week', strtotime($selectedDate)));
$endOfWeek = date('Y-m-d', strtotime('sunday this week', strtotime($selectedDate)));

$stmt = $pdo->prepare('SELECT p.*, u.name AS cliente FROM packages p LEFT JOIN users u ON p.customer_id = u.id WHERE p.assigned_to = :id AND p.status = "entregado" AND DATE(p.updated_at) BETWEEN :start AND :end ORDER BY p.updated_at DESC');
$stmt->execute(['id' => $user['id'], 'start' => $startOfWeek, 'end' => $endOfWeek]);
$deliveries = $stmt->fetchAll();

$totalRevenue = array_sum(array_column($deliveries, 'delivery_fee'));

$title = 'Entregas semanales';
require __DIR__ . '/../includes/header.php';
?>
<div class="d-flex">
    <?php require __DIR__ . '/../includes/sidebar.php'; ?>
    <div class="flex-grow-1 p-4">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h1 class="h3 mb-1 text-primary"><i class="fas fa-calendar-week me-2"></i>Entregas de la semana</h1>
                <p class="text-muted mb-0">Del <?php echo date('d/m/Y', strtotime($startOfWeek)); ?> al <?php echo date('d/m/Y', strtotime($endOfWeek)); ?></p>
            </div>
            <div>
                <form method="get" class="d-flex me-2">
                    <input type="date" name="week" value="<?php echo esc($selectedDate); ?>" class="form-control me-2" style="width: auto;">
                    <button type="submit" class="btn btn-outline-primary">
                        <i class="fas fa-search me-1"></i>Seleccionar semana
                    </button>
                </form>
                <a href="download_pdf.php?week=<?php echo urlencode($selectedDate); ?>" class="btn btn-success btn-lg">
                    <i class="fas fa-download me-2"></i>Descargar PDF
                </a>
            </div>
        </div>
        <div class="row g-3 mb-4">
            <div class="col-md-6">
                <div class="card shadow-sm border-primary">
                    <div class="card-body text-center">
                        <i class="fas fa-box fa-2x text-primary mb-2"></i>
                        <h6 class="text-uppercase text-muted">Total entregas</h6>
                        <h2 class="text-primary"><?php echo count($deliveries); ?></h2>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="card shadow-sm border-success">
                    <div class="card-body text-center">
                        <i class="fas fa-dollar-sign fa-2x text-success mb-2"></i>
                        <h6 class="text-uppercase text-muted">Ganancias</h6>
                        <h2 class="text-success">$<?php echo number_format($totalRevenue, 2); ?></h2>
                    </div>
                </div>
            </div>
        </div>
        <div class="card shadow-sm">
            <div class="card-header bg-primary text-white">
                <h5 class="card-title mb-0"><i class="fas fa-list"></i> Listado de entregas</h5>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0">
                        <thead class="table-light">
                            <tr>
                                <th><i class="fas fa-hashtag text-primary"></i> Código</th>
                                <th><i class="fas fa-user text-primary"></i> Cliente</th>
                                <th><i class="fas fa-map-marker text-primary"></i> Destino</th>
                                <th><i class="fas fa-calendar-check text-primary"></i> Fecha entrega</th>
                                <th><i class="fas fa-dollar-sign text-primary"></i> Tarifa</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php if ($deliveries): foreach ($deliveries as $pkg): ?>
                            <tr>
                                <td><span class="badge bg-secondary"><?php echo esc($pkg['code']); ?></span></td>
                                <td><?php echo esc($pkg['cliente'] ?? 'N/E'); ?></td>
                                <td><?php echo esc($pkg['destination']); ?></td>
                                <td><?php echo date('d/m/Y H:i', strtotime($pkg['updated_at'])); ?></td>
                                <td class="text-success fw-bold">$<?php echo number_format($pkg['delivery_fee'], 2); ?></td>
                            </tr>
                        <?php endforeach; else: ?>
                            <tr>
                                <td colspan="5" class="text-center py-4">
                                    <i class="fas fa-inbox fa-2x text-muted mb-2"></i>
                                    <br>No hay entregas esta semana.
                                </td>
                            </tr>
                        <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php require __DIR__ . '/../includes/footer.php';
