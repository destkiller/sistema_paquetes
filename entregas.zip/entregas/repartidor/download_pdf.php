<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';
requireRole('repartidor');

require_once __DIR__ . '/../includes/fpdf/fpdf.php';

$user = currentUser();
// Obtener semana seleccionada o actual
$selectedDate = $_GET['week'] ?? date('Y-m-d');
$startOfWeek = date('Y-m-d', strtotime('monday this week', strtotime($selectedDate)));
$endOfWeek = date('Y-m-d', strtotime('sunday this week', strtotime($selectedDate)));

$stmt = $pdo->prepare('SELECT p.*, u.name AS cliente FROM packages p LEFT JOIN users u ON p.customer_id = u.id WHERE p.assigned_to = :id AND p.status = "entregado" AND DATE(p.updated_at) BETWEEN :start AND :end ORDER BY p.updated_at DESC');
$stmt->execute(['id' => $user['id'], 'start' => $startOfWeek, 'end' => $endOfWeek]);
$deliveries = $stmt->fetchAll();

$totalRevenue = array_sum(array_column($deliveries, 'delivery_fee'));

// Crear PDF
$pdf = new FPDF();
$pdf->AddPage();
$pdf->SetFont('Helvetica', 'B', 16);
$pdf->Cell(0, 10, 'Entregas Semanales - ' . esc($user['name']), 0, 1, 'C');
$pdf->Ln(10);

$pdf->SetFont('Helvetica', '', 12);
$pdf->Cell(0, 10, 'Periodo: ' . date('d/m/Y', strtotime($startOfWeek)) . ' - ' . date('d/m/Y', strtotime($endOfWeek)), 0, 1);
$pdf->Cell(0, 10, 'Total entregas: ' . count($deliveries), 0, 1);
$pdf->Cell(0, 10, 'Ganancias totales: $' . number_format($totalRevenue, 2), 0, 1);
$pdf->Ln(10);

// Tabla
$pdf->SetFont('Helvetica', 'B', 10);
$pdf->Cell(30, 10, 'Codigo', 1);
$pdf->Cell(40, 10, 'Cliente', 1);
$pdf->Cell(50, 10, 'Destino', 1);
$pdf->Cell(30, 10, 'Fecha', 1);
$pdf->Cell(20, 10, 'Tarifa', 1);
$pdf->Ln();

$pdf->SetFont('Helvetica', '', 10);
foreach ($deliveries as $pkg) {
    $pdf->Cell(30, 10, esc($pkg['code']), 1);
    $pdf->Cell(40, 10, esc($pkg['cliente'] ?? 'N/E'), 1);
    $pdf->Cell(50, 10, esc($pkg['destination']), 1);
    $pdf->Cell(30, 10, date('d/m/Y', strtotime($pkg['updated_at'])), 1);
    $pdf->Cell(20, 10, '$' . number_format($pkg['delivery_fee'], 2), 1);
    $pdf->Ln();
}

$pdf->Output('D', 'entregas_semanales_' . date('Y-m-d') . '.pdf');
