<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';
requireRole('repartidor');

$user = currentUser();
function statusLabel($status) {
    $labels = [
        'recibido' => 'Recibido',
        'en_transito' => 'En tránsito',
        'entregado' => 'Entregado'
    ];
    return $labels[$status] ?? $status;
}
$stmt = $pdo->prepare('SELECT p.*, u.name AS cliente FROM packages p LEFT JOIN users u ON p.customer_id = u.id WHERE p.assigned_to = :id ORDER BY p.created_at DESC');
$stmt->execute(['id' => $user['id']]);
$packages = $stmt->fetchAll();
$revenue = getDeliveryRevenueForUser($pdo, $user['id']);
$title = 'Panel repartidor';
require __DIR__ . '/../includes/header.php';
?>
<div class="d-flex">
    <?php require __DIR__ . '/../includes/sidebar.php'; ?>
    <div class="flex-grow-1 p-4">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h1 class="h3 mb-1 text-primary"><i class="fas fa-tachometer-alt me-2"></i>Bienvenido, <?php echo esc($user['name']); ?></h1>
                <p class="text-muted mb-0">Visualiza tus entregas y ganancias.</p>
            </div>
            <div>
                <a href="weekly_deliveries.php" class="btn btn-outline-primary btn-lg">
                    <i class="fas fa-calendar-week me-2"></i>Entregas semanales
                </a>
            </div>
        </div>
        <div class="row g-3 mb-4">
            <div class="col-md-4">
                <div class="card shadow-sm border-primary">
                    <div class="card-body text-center">
                        <i class="fas fa-box fa-2x text-primary mb-2"></i>
                        <h6 class="text-uppercase text-muted">Total entregas</h6>
                        <h2 class="text-primary"><?php echo count($packages); ?></h2>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card shadow-sm border-success">
                    <div class="card-body text-center">
                        <i class="fas fa-dollar-sign fa-2x text-success mb-2"></i>
                        <h6 class="text-uppercase text-muted">Ganancias</h6>
                        <h2 class="text-success">$<?php echo number_format($revenue, 2); ?></h2>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card shadow-sm border-info">
                    <div class="card-body text-center">
                        <i class="fas fa-info-circle fa-2x text-info mb-2"></i>
                        <h6 class="text-uppercase text-muted">Último estado</h6>
                        <h2 class="text-info"><?php echo statusLabel($packages[0]['status'] ?? 'Sin entregas'); ?></h2>
                    </div>
                </div>
            </div>
        </div>
        <div class="card shadow-sm">
            <div class="card-header bg-primary text-white">
                <h5 class="card-title mb-0"><i class="fas fa-list"></i> Mis paquetes asignados</h5>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0">
                        <thead class="table-light">
                            <tr>
                                <th><i class="fas fa-hashtag text-primary"></i> Código</th>
                                <th><i class="fas fa-user text-primary"></i> Cliente</th>
                                <th><i class="fas fa-map-marker text-primary"></i> Destino</th>
                                <th><i class="fas fa-info-circle text-primary"></i> Estado</th>
                                <th><i class="fas fa-dollar-sign text-primary"></i> Tarifa</th>
                                <th><i class="fas fa-cogs text-primary"></i> Acciones</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php if ($packages): foreach ($packages as $pkg): ?>
                            <tr>
                                <td><span class="badge bg-secondary"><?php echo esc($pkg['code']); ?></span></td>
                                <td><?php echo esc($pkg['cliente'] ?? 'N/E'); ?></td>
                                <td><?php echo esc($pkg['destination']); ?></td>
                                <td>
                                    <?php
                                    $statusClass = match($pkg['status']) {
                                        'recibido' => 'bg-warning',
                                        'en_transito' => 'bg-info',
                                        'entregado' => 'bg-success',
                                        default => 'bg-secondary'
                                    };
                                    ?>
                                    <span class="badge <?php echo $statusClass; ?>"><?php echo statusLabel($pkg['status']); ?></span>
                                </td>
                                <td class="text-success fw-bold">$<?php echo number_format($pkg['delivery_fee'], 2); ?></td>
                                <td>
                                    <a href="package_detail.php?id=<?php echo esc($pkg['id']); ?>" class="btn btn-sm btn-primary">
                                        <i class="fas fa-eye me-1"></i>Ver detalle
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; else: ?>
                            <tr>
                                <td colspan="6" class="text-center py-4">
                                    <i class="fas fa-inbox fa-2x text-muted mb-2"></i>
                                    <br>No tienes paquetes asignados todavía.
                                </td>
                            </tr>
                        <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php require __DIR__ . '/../includes/footer.php';
