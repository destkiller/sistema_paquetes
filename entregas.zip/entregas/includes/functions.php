<?php

function esc($value)
{
    return htmlspecialchars($value, ENT_QUOTES, 'UTF-8');
}

function redirect($path)
{
    header('Location: ' . $path);
    exit;
}

function isLoggedIn()
{
    return !empty($_SESSION['user']);
}

function requireLogin()
{
    if (!isLoggedIn()) {
        $config = require __DIR__ . '/../config.php';
        redirect($config['base_url'] . '/index.php');
    }
}

function requireRole($role)
{
    requireLogin();
    if ($_SESSION['user']['role'] !== $role) {
        http_response_code(403);
        echo 'Acceso denegado.';
        exit;
    }
}

function getUserCount(PDO $pdo)
{
    $stmt = $pdo->query('SELECT COUNT(*) FROM users');
    return (int) $stmt->fetchColumn();
}

function getPackageCount(PDO $pdo)
{
    $stmt = $pdo->query('SELECT COUNT(*) FROM packages');
    return (int) $stmt->fetchColumn();
}

function getAssignedCount(PDO $pdo)
{
    $stmt = $pdo->query('SELECT COUNT(*) FROM packages WHERE status = "en_transito"');
    return (int) $stmt->fetchColumn();
}

function getTotalRevenue(PDO $pdo)
{
    $stmt = $pdo->query('SELECT IFNULL(SUM(delivery_fee), 0) FROM packages WHERE status = "entregado"');
    return (float) $stmt->fetchColumn();
}

function getDeliveryRevenueForUser(PDO $pdo, $userId)
{
    $stmt = $pdo->prepare('SELECT IFNULL(SUM(delivery_fee), 0) FROM packages WHERE status = "entregado" AND assigned_to = :user_id');
    $stmt->execute(['user_id' => $userId]);
    return (float) $stmt->fetchColumn();
}
