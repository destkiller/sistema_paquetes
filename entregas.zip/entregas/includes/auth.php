<?php

session_start();
require_once __DIR__ . '/../db.php';

function getUserByEmail(PDO $pdo, $email)
{
    $stmt = $pdo->prepare('SELECT * FROM users WHERE email = :email LIMIT 1');
    $stmt->execute(['email' => $email]);
    return $stmt->fetch();
}

function loginUser(PDO $pdo, $email, $password)
{
    $user = getUserByEmail($pdo, $email);
    if (!$user) {
        return false;
    }

    $valid = password_verify($password, $user['password']) || $user['password'] === $password;
    if (!$valid) {
        return false;
    }

    if (!password_verify($password, $user['password'])) {
        $hash = password_hash($password, PASSWORD_DEFAULT);
        $stmt = $pdo->prepare('UPDATE users SET password = :pass WHERE id = :id');
        $stmt->execute(['pass' => $hash, 'id' => $user['id']]);
        $user['password'] = $hash;
    }

    unset($user['password']);
    $_SESSION['user'] = $user;
    return true;
}

function logoutUser()
{
    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
        $params = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000,
            $params['path'], $params['domain'],
            $params['secure'], $params['httponly']
        );
    }
    session_destroy();
}

function currentUser()
{
    return $_SESSION['user'] ?? null;
}
