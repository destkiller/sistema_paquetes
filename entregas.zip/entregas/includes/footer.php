    <!-- MDBootstrap JS -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/6.4.0/mdb.min.js"></script>
    <!-- jQuery Animations -->
    <script>
        $(document).ready(function() {
            // Animate cards on load
            $('.card').each(function(index) {
                $(this).hide().delay(index * 200).fadeIn(800);
            });

            // Animate table rows
            $('tbody tr').each(function(index) {
                $(this).hide().delay(index * 100).slideDown(600);
            });

            // Button hover effects
            $('.btn').hover(
                function() { $(this).fadeTo(200, 0.8); },
                function() { $(this).fadeTo(200, 1); }
            );

            // Form inputs focus animation
            $('.form-control').focus(function() {
                $(this).animate({ borderWidth: '2px' }, 300);
            }).blur(function() {
                $(this).animate({ borderWidth: '1px' }, 300);
            });

            // Alert messages slide down with bounce
            $('.alert').hide().slideDown(500).addClass('animate__animated animate__bounceIn');
            
            // Special animation for success alerts
            $('.alert-success').each(function() {
                var $alert = $(this);
                setTimeout(function() {
                    $alert.addClass('animate__pulse');
                }, 1000);
            });

            // Bootstrap form validation
            (function () {
                'use strict'
                var forms = document.querySelectorAll('.needs-validation')
                Array.prototype.slice.call(forms)
                    .forEach(function (form) {
                        form.addEventListener('submit', function (event) {
                            if (!form.checkValidity()) {
                                event.preventDefault()
                                event.stopPropagation()
                            }
                            form.classList.add('was-validated')
                        }, false)
                    })
            })();

            // Global check animation function
            // Usage: showCheckAnimation({message: "¡Éxito!", duration: 2000, type: "overlay|toast"})
            window.showCheckAnimation = function(options) {
                options = options || {};
                var message = options.message || '¡Éxito!';
                var duration = options.duration || 2000;
                var type = options.type || 'overlay'; // overlay, toast
                var position = options.position || 'center'; // center, top-right
                
                if (type === 'toast') {
                    // Toast version
                    var $toast = $('<div class="check-success-toast">' +
                        '<div class="d-flex align-items-center">' +
                            '<i class="fas fa-check-circle text-success me-2 fa-lg"></i>' +
                            '<span class="fw-bold">' + message + '</span>' +
                        '</div>' +
                    '</div>');
                    
                    $('body').append($toast);
                    
                    setTimeout(function() {
                        $toast.fadeOut(500, function() { $(this).remove(); });
                    }, duration);
                    
                } else {
                    // Overlay version (default)
                    var $checkAnim = $('<div class="check-animation-overlay" style="position: fixed; top: 0; left: 0; right: 0; bottom: 0; background: rgba(40, 167, 69, 0.1); display: flex; align-items: center; justify-content: center; z-index: 9999; pointer-events: none;">' +
                        '<div class="check-animation-content text-center">' +
                            '<div class="check-icon-wrapper mb-3">' +
                                '<i class="fas fa-check-circle fa-4x text-success animate__animated animate__bounceIn"></i>' +
                            '</div>' +
                            '<div class="check-message fw-bold text-success fs-4 animate__animated animate__fadeInUp">' + message + '</div>' +
                        '</div>' +
                    '</div>');
                    
                    // Adjust position if specified
                    if (position === 'top-right') {
                        $checkAnim.css({
                            'justify-content': 'flex-end',
                            'align-items': 'flex-start',
                            'padding': '2rem'
                        });
                        $checkAnim.find('.check-animation-content').css({
                            'text-align': 'right'
                        });
                    }
                    
                    // Add to body
                    $('body').append($checkAnim);
                    
                    // Animate in
                    $checkAnim.hide().fadeIn(300);
                    
                    // Add pulse effect to icon
                    setTimeout(function() {
                        $checkAnim.find('.fa-check-circle').addClass('animate__pulse');
                    }, 600);
                    
                    // Auto remove after duration
                    setTimeout(function() {
                        $checkAnim.fadeOut(500, function() {
                            $(this).remove();
                        });
                    }, duration);
                }
            };

            // Auto-trigger check animation on success messages
            if ($('.alert-success').length > 0) {
                setTimeout(function() {
                    showCheckAnimation({
                        message: '¡Operación completada!',
                        duration: 2500
                    });
                }, 500);
            }

            // Save animation on form submit
            $('form').on('submit', function(e) {
                var $form = $(this);
                var $submitBtn = $form.find('button[type="submit"], input[type="submit"]');
                
                // Prevent double submission
                if ($form.data('submitting')) {
                    e.preventDefault();
                    return false;
                }
                $form.data('submitting', true);
                
                // Show loading state on button
                var originalText = $submitBtn.html();
                $submitBtn.html('<i class="fas fa-spinner fa-spin me-2"></i>Guardando...');
                
                // Add saving overlay to the card or container
                var $container = $form.closest('.card, .container');
                if ($container.length === 0) $container = $form;
                
                $container.css('position', 'relative');
                var $overlay = $('<div class="saving-overlay" style="position: absolute; top: 0; left: 0; right: 0; bottom: 0; background: rgba(255,255,255,0.9); display: flex; align-items: center; justify-content: center; z-index: 1000; border-radius: 0.375rem;">' +
                    '<div class="text-center">' +
                        '<i class="fas fa-save fa-3x text-primary mb-3 animate__animated animate__bounceIn"></i>' +
                        '<div class="fw-bold text-primary fs-5 mb-2">Guardando cambios...</div>' +
                        '<div class="spinner-border text-primary" role="status" style="width: 2rem; height: 2rem;">' +
                            '<span class="visually-hidden">Cargando...</span>' +
                        '</div>' +
                    '</div>' +
                '</div>');
                
                $container.append($overlay);
                
                // Animate overlay appearance
                $overlay.hide().fadeIn(300);
                
                // Add some bounce animation to the icon
                setTimeout(function() {
                    $overlay.find('i').addClass('animate__bounce');
                }, 500);
                
                // Delay submission slightly to show animation
                e.preventDefault();
                setTimeout(function() {
                    $form.off('submit').submit(); // Remove handler and submit
                }, 800);
            });

            // User detail modal handler - DESACTIVADO: Ahora se abre en página completa
            /*
            $(document).on('click', '.btn-user-detail', function(e) {
                e.preventDefault();
                var userId = $(this).data('user-id');
                var $modal = $('#userDetailModal');
                
                // Show loading state
                $modal.find('.modal-body').html(
                    '<div class="text-center p-4">' +
                    '<div class="spinner-border text-primary" role="status">' +
                    '<span class="visually-hidden">Cargando...</span>' +
                    '</div>' +
                    '</div>'
                );
                
                // Fetch user details
                $.ajax({
                    url: 'get_user_detail.php?id=' + userId,
                    type: 'GET',
                    dataType: 'json',
                    success: function(data) {
                        if (data.error) {
                            $modal.find('.modal-body').html('<div class="alert alert-danger">' + data.error + '</div>');
                            return;
                        }
                        
                        var user = data.user;
                        var stats = data.stats;
                        var deliveries = data.deliveries;
                        var packages = data.packages;
                        
                        // Build modal content
                        var content = '<div class="user-detail-content">' +
                            '<div class="user-header mb-4 pb-3 border-bottom">' +
                            '<div class="row align-items-center">' +
                            '<div class="col-auto">' +
                            '<div class="avatar-circle" style="width: 60px; height: 60px; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); border-radius: 50%; display: flex; align-items: center; justify-content: center; color: white; font-size: 28px;">' +
                            '<i class="fas fa-user"></i>' +
                            '</div>' +
                            '</div>' +
                            '<div class="col">' +
                            '<h5 class="mb-0">' + escapeHtml(user.name) + '</h5>' +
                            '<small class="text-muted">' + escapeHtml(user.email) + '</small>' +
                            '</div>' +
                            '<div class="col-auto text-end">' +
                            '<span class="badge ' + (user.role === 'admin' ? 'bg-danger' : user.role === 'repartidor' ? 'bg-info' : 'bg-success') + ' px-3 py-2">' + user.role.toUpperCase() + '</span>' +
                            '</div>' +
                            '</div>' +
                            '</div>';
                        
                        // User info
                        content += '<div class="user-info mb-4">' +
                            '<div class="row">' +
                            '<div class="col-md-6">' +
                            '<small class="text-muted d-block">Email:</small>' +
                            '<span>' + escapeHtml(user.email) + '</span>' +
                            '</div>' +
                            '<div class="col-md-6">' +
                            '<small class="text-muted d-block">Registrado:</small>' +
                            '<span>' + new Date(user.created_at).toLocaleDateString('es-ES') + '</span>' +
                            '</div>' +
                            '</div>' +
                            '</div>';
                        
                        // Statistics for repartidor
                        if (user.role === 'repartidor' && stats.total_packages > 0) {
                            content += '<div class="stats-section mb-4">' +
                                '<h6 class="mb-3 fw-bold"><i class="fas fa-chart-bar text-primary me-2"></i>Estadísticas</h6>' +
                                '<div class="row g-2">' +
                                '<div class="col-6 col-md-3">' +
                                '<div class="stat-card p-3 bg-light rounded text-center">' +
                                '<div class="stat-value text-primary fw-bold fs-5">' + stats.total_packages + '</div>' +
                                '<small class="text-muted">Total entregado</small>' +
                                '</div>' +
                                '</div>' +
                                '<div class="col-6 col-md-3">' +
                                '<div class="stat-card p-3 bg-light rounded text-center">' +
                                '<div class="stat-value text-success fw-bold fs-5">' + stats.delivered_packages + '</div>' +
                                '<small class="text-muted">Entregados</small>' +
                                '</div>' +
                                '</div>' +
                                '<div class="col-6 col-md-3">' +
                                '<div class="stat-card p-3 bg-light rounded text-center">' +
                                '<div class="stat-value text-info fw-bold fs-5">' + stats.in_transit_packages + '</div>' +
                                '<small class="text-muted">En tránsito</small>' +
                                '</div>' +
                                '</div>' +
                                '<div class="col-6 col-md-3">' +
                                '<div class="stat-card p-3 bg-light rounded text-center">' +
                                '<div class="stat-value text-success fw-bold fs-5">$' + stats.total_revenue.toFixed(2) + '</div>' +
                                '<small class="text-muted">Ingresos</small>' +
                                '</div>' +
                                '</div>' +
                                '</div>' +
                                '</div>';
                        }
                        
                        // Deliveries list for repartidor
                        if (user.role === 'repartidor' && deliveries.length > 0) {
                            content += '<div class="deliveries-section">' +
                                '<h6 class="mb-3 fw-bold"><i class="fas fa-box text-primary me-2"></i>Entregas Recientes</h6>' +
                                '<div class="table-responsive">' +
                                '<table class="table table-sm table-hover">' +
                                '<thead class="table-light"><tr>' +
                                '<th>Paquete</th><th>Destino</th><th>Estado</th><th>Fecha</th>' +
                                '</tr></thead><tbody>';
                                
                            deliveries.slice(0, 10).forEach(function(pkg) {
                                var badgeClass = pkg.status === 'entregado' ? 'bg-success' : pkg.status === 'en_transito' ? 'bg-info' : 'bg-warning';
                                content += '<tr><td><small>' + escapeHtml(pkg.code) + '</small></td>' +
                                    '<td><small>' + escapeHtml(pkg.destination) + '</small></td>' +
                                    '<td><span class="badge ' + badgeClass + ' fs-6">' + pkg.status + '</span></td>' +
                                    '<td><small>' + new Date(pkg.updated_at).toLocaleDateString('es-ES') + '</small></td></tr>';
                            });
                            
                            content += '</tbody>' +
                                '</table>' +
                                '</div>' +
                                '</div>';
                        }
                        
                        // Packages list for cliente
                        if (user.role === 'cliente' && packages.length > 0) {
                            content += '<div class="packages-section">' +
                                '<h6 class="mb-3 fw-bold"><i class="fas fa-shopping-box text-primary me-2"></i>Paquetes</h6>' +
                                '<div class="table-responsive">' +
                                '<table class="table table-sm table-hover">' +
                                '<thead class="table-light"><tr>' +
                                '<th>Código</th><th>Destino</th><th>Repartidor</th><th>Estado</th>' +
                                '</tr></thead><tbody>';
                                
                            packages.slice(0, 10).forEach(function(pkg) {
                                var badgeClass = pkg.status === 'entregado' ? 'bg-success' : pkg.status === 'en_transito' ? 'bg-info' : 'bg-warning';
                                content += '<tr><td><small>' + escapeHtml(pkg.code) + '</small></td>' +
                                    '<td><small>' + escapeHtml(pkg.destination) + '</small></td>' +
                                    '<td><small>' + (pkg.repartidor ? escapeHtml(pkg.repartidor) : '<em class="text-muted">No asignado</em>') + '</small></td>' +
                                    '<td><span class="badge ' + badgeClass + '">' + pkg.status + '</span></td></tr>';
                            });
                            
                            content += '</tbody>' +
                                '</table>' +
                                '</div>' +
                                '</div>';
                        }
                        
                        content += '</div>';
                        
                        $modal.find('.modal-body').html(content);
                        $modal.find('.modal-title').html('<i class="fas fa-user-circle me-2 text-primary"></i>' + escapeHtml(user.name));
                    },
                    error: function() {
                        $modal.find('.modal-body').html('<div class="alert alert-danger">Error al cargar los datos del usuario.</div>');
                    }
                });
            });
            
            // Helper function to escape HTML
            function escapeHtml(text) {
                var div = document.createElement('div');
                div.textContent = text;
                return div.innerHTML;
            }
            */ // Fin del código del modal - DESACTIVADO
        });
    </script>
    
    <!-- User Detail Modal - DESACTIVADO (Se usa página completa en su lugar)
    <div class="modal fade" id="userDetailModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-scrollable">
            <div class="modal-content">
                <div class="modal-header bg-primary text-white">
                    <h5 class="modal-title"><i class="fas fa-user-circle me-2"></i>Detalle del Usuario</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <!-- Content will be loaded here -->
                </div>
            </div>
        </div>
    </div>

    <!-- DataTables JS -->
    <script src="https://cdn.datatables.net/1.13.7/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.7/js/dataTables.bootstrap5.min.js"></script>
    <script src="https://cdn.datatables.net/responsive/2.5.0/js/dataTables.responsive.min.js"></script>
    <script src="https://cdn.datatables.net/responsive/2.5.0/js/responsive.bootstrap5.min.js"></script>
    
    <!-- Footer -->
    <footer class="bg-dark text-white py-4 mt-5 border-top" style="border-color: var(--ms-blue) !important; background: linear-gradient(135deg, rgba(0,0,0,0.95) 0%, rgba(16, 14, 20, 0.95) 100%) !important; border-top-width: 3px !important;">
        <div class="container-fluid">
            <div class="row align-items-center">
                <div class="col-12 text-center">
                    <p class="mb-0 opacity-75">
                        <i class="fas fa-code me-2" style="color: var(--ms-green);"></i>
                        Creado por <strong>Ukonex IT Holding Group</strong>
                    </p>
                    <p class="mb-0 small opacity-50 mt-2">
                        <i class="far fa-copyright me-1"></i>2026 - Todos los derechos reservados
                    </p>
                </div>
            </div>
        </div>
    </footer>
</body>
</html>
