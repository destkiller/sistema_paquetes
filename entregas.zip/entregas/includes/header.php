<?php
$config = require __DIR__ . '/../config.php';
$baseUrl = $config['base_url'];
$title = $title ?? 'Entregas';
?>
<!doctype html>
<html lang="es">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo htmlspecialchars($title); ?> - Entregas</title>
    <!-- MDBootstrap CSS -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/6.4.0/mdb.min.css" rel="stylesheet">
    <!-- Animate.css -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" rel="stylesheet">
    <!-- Material Icons -->
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <style>
        :root {
            --ms-blue: #0078D4;
            --ms-blue-dark: #106EBE;
            --ms-green: #107C10;
            --ms-red: #D83B01;
            --ms-yellow: #FFB900;
            --ms-gray: #8A8886;
            --ms-gray-light: #F3F2F1;
        }
        
        body { 
            min-height: 100vh; 
            background: var(--ms-gray-light);
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
        }
        
        .sidebar {
            min-height: 100vh;
            background: linear-gradient(135deg, var(--ms-blue) 0%, var(--ms-blue-dark) 100%);
            color: #fff;
            border-right: 3px solid var(--ms-red);
        }
        
        .sidebar a { 
            color: rgba(255,255,255,.85);
            transition: all 0.3s ease;
        }
        
        .sidebar a.active { 
            color: #fff; 
            text-decoration: none; 
            background: rgba(255,255,255,.15);
            border-left: 4px solid var(--ms-yellow);
            padding-left: calc(1.1rem - 4px);
        }
        
        .sidebar a:hover { 
            color: #fff; 
            text-decoration: none; 
            background: rgba(255,255,255,.1);
        }
        
        .sidebar .nav-link { 
            padding: .9rem 1.1rem;
            border-left: 4px solid transparent;
        }
        
        .card-soft { 
            background: linear-gradient(135deg, rgba(0, 120, 212, 0.08) 0%, rgba(16, 110, 190, 0.08) 100%);
        }
        
        .topbar { 
            background: #fff; 
            border-bottom: 2px solid var(--ms-blue);
        }
        
        .badge-role { 
            text-transform: uppercase; 
            letter-spacing: .05em;
        }
        
        .table-responsive { 
            min-height: 250px;
        }
        
        .saving-overlay {
            backdrop-filter: blur(2px);
            animation: pulse 1.5s infinite;
            background: rgba(0, 120, 212, 0.15);
        }
        
        @keyframes pulse {
            0% { opacity: 0.8; }
            50% { opacity: 1; }
            100% { opacity: 0.8; }
        }
        
        .check-animation-overlay {
            backdrop-filter: blur(1px);
        }
        
        .check-icon-wrapper {
            animation: checkScale 0.6s ease-out;
        }
        
        @keyframes checkScale {
            0% { transform: scale(0); }
            50% { transform: scale(1.2); }
            100% { transform: scale(1); }
        }
        
        .check-success-toast {
            position: fixed;
            top: 20px;
            right: 20px;
            background: linear-gradient(135deg, var(--ms-green) 0%, #0B6A1F 100%);
            color: #fff;
            border: 2px solid var(--ms-green);
            border-radius: 0.375rem;
            padding: 1rem;
            box-shadow: 0 0.5rem 1rem rgba(0, 0, 0, 0.2);
            z-index: 9999;
            max-width: 300px;
            animation: slideInRight 0.5s ease-out;
        }
        
        @keyframes slideInRight {
            from { transform: translateX(100%); opacity: 0; }
            to { transform: translateX(0); opacity: 1; }
        }
        
        .user-detail-content {
            animation: fadeIn 0.4s ease-in;
        }
        
        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }
        
        .avatar-circle {
            box-shadow: 0 2px 8px rgba(0, 120, 212, 0.3);
        }
        
        .stat-card {
            border-left: 4px solid var(--ms-blue);
            transition: all 0.3s ease;
        }
        
        .stat-card:hover {
            transform: translateY(-2px);
            box-shadow: 0 0.5rem 1rem rgba(0, 0, 0, 0.1);
        }
        
        .btn-user-detail {
            cursor: pointer;
            transition: all 0.3s ease;
            color: var(--ms-blue);
        }
        
        .btn-user-detail:hover {
            text-decoration: underline !important;
            color: var(--ms-blue-dark) !important;
        }
        
        .package-search-input:focus {
            box-shadow: 0 0 0 0.2rem rgba(0, 120, 212, 0.25);
            border-color: var(--ms-blue);
        }
        
        #packageSearchInput {
            transition: all 0.3s ease;
            font-size: 0.95rem;
            border-color: var(--ms-blue);
        }
        
        #packageSearchInput::placeholder {
            color: var(--ms-gray);
            font-style: italic;
        }
        
        #noResultsAlert {
            animation: fadeIn 0.3s ease-in;
        }
        
        .package-row {
            transition: all 0.2s ease;
        }
        
        .package-row:hover {
            background-color: var(--ms-gray-light) !important;
        }
        
        .btn { 
            border-radius: 50px;
            transition: all 0.3s ease;
        }
        
        .btn-primary {
            background-color: var(--ms-blue);
            border-color: var(--ms-blue);
        }
        
        .btn-primary:hover {
            background-color: var(--ms-blue-dark);
            border-color: var(--ms-blue-dark);
        }
        
        .btn-success {
            background-color: var(--ms-green);
            border-color: var(--ms-green);
        }
        
        .btn-success:hover {
            background-color: #0B6A1F;
            border-color: #0B6A1F;
        }
        
        .btn-danger {
            background-color: var(--ms-red);
            border-color: var(--ms-red);
        }
        
        .btn-danger:hover {
            background-color: #B7340A;
            border-color: #B7340A;
        }
        
        .btn-warning {
            background-color: var(--ms-yellow);
            border-color: var(--ms-yellow);
            color: #000;
        }
        
        .btn-warning:hover {
            background-color: #E8A300;
            border-color: #E8A300;
            color: #000;
        }
        
        .card { 
            border-radius: 8px; 
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
            border: 1px solid #E1DFDD;
        }
        
        .form-control { 
            border-radius: 4px;
            border: 1px solid var(--ms-gray);
        }
        
        .form-control:focus {
            border-color: var(--ms-blue);
            box-shadow: 0 0 0 0.2rem rgba(0, 120, 212, 0.25);
        }
        
        .badge {
            border-radius: 3px;
            font-weight: 600;
        }
        
        .badge-primary {
            background-color: var(--ms-blue);
        }
        
        .badge-success {
            background-color: var(--ms-green);
        }
        
        .badge-info {
            background-color: #0078AD;
        }
        
        .badge-warning {
            background-color: var(--ms-yellow);
            color: #000;
        }
        
        .badge-danger {
            background-color: var(--ms-red);
        }
        
        .dataTables_wrapper .dataTables_paginate .paginate_button.current {
            background: var(--ms-blue);
            color: #fff;
            border: 1px solid var(--ms-blue);
        }
        
        .dataTables_wrapper .dataTables_paginate .paginate_button:hover {
            background: var(--ms-blue-dark);
            color: #fff;
            border: 1px solid var(--ms-blue-dark);
        }
    </style>
    <!-- DataTables Bootstrap 5 CSS -->
    <link href="https://cdn.datatables.net/1.13.7/css/dataTables.bootstrap5.min.css" rel="stylesheet">
    <link href="https://cdn.datatables.net/responsive/2.5.0/css/responsive.bootstrap5.min.css" rel="stylesheet">
</head>
<body>
