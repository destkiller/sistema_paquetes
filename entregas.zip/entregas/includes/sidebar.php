<?php
$user = $_SESSION['user'] ?? null;
$role = $user['role'] ?? 'admin';
$active = function($path) {
    return strpos($_SERVER['REQUEST_URI'], $path) !== false ? 'active' : '';
};
?>
<div class="sidebar d-flex flex-column p-3 text-white">
    <a href="<?php echo $baseUrl; ?>/admin/dashboard.php" class="d-flex align-items-center mb-3 text-white text-decoration-none logo-brand">
        <div class="sidebar-logo-icon me-2">
            <i class="material-icons">local_shipping</i>
        </div>
        <span class="fs-4 fw-bold">Entregas</span>
    </a>
    <hr class="text-white-50">
    <ul class="nav nav-pills flex-column mb-auto">
        <?php if ($role === 'admin'): ?>
            <li class="nav-item">
                <a href="<?php echo $baseUrl; ?>/admin/dashboard.php" class="nav-link sidebar-link <?php echo $active('/admin/dashboard.php'); ?>">
                    <div class="sidebar-icon">
                        <i class="material-icons">dashboard</i>
                    </div>
                    <span class="nav-text">Dashboard</span>
                </a>
            </li>
            <li class="nav-item">
                <a href="<?php echo $baseUrl; ?>/admin/users.php" class="nav-link sidebar-link <?php echo $active('/admin/users.php'); ?>">
                    <div class="sidebar-icon">
                        <i class="material-icons">people</i>
                    </div>
                    <span class="nav-text">Usuarios</span>
                </a>
            </li>
            <li class="nav-item">
                <a href="<?php echo $baseUrl; ?>/admin/packages.php" class="nav-link sidebar-link <?php echo $active('/admin/packages.php'); ?>">
                    <div class="sidebar-icon">
                        <i class="material-icons">inventory</i>
                    </div>
                    <span class="nav-text">Paquetes</span>
                </a>
            </li>
            <li class="nav-item">
                <a href="<?php echo $baseUrl; ?>/admin/assign.php" class="nav-link sidebar-link <?php echo $active('/admin/assign.php'); ?>">
                    <div class="sidebar-icon">
                        <i class="material-icons">assignment</i>
                    </div>
                    <span class="nav-text">Asignar entregas</span>
                </a>
            </li>
        <?php elseif ($role === 'repartidor'): ?>
            <li class="nav-item">
                <a href="<?php echo $baseUrl; ?>/repartidor/dashboard.php" class="nav-link sidebar-link <?php echo $active('/repartidor/dashboard.php'); ?>">
                    <div class="sidebar-icon">
                        <i class="material-icons">dashboard</i>
                    </div>
                    <span class="nav-text">Dashboard</span>
                </a>
            </li>
            <li class="nav-item">
                <a href="<?php echo $baseUrl; ?>/repartidor/packages.php" class="nav-link sidebar-link <?php echo $active('/repartidor/packages.php'); ?>">
                    <div class="sidebar-icon">
                        <i class="material-icons">inventory</i>
                    </div>
                    <span class="nav-text">Mis paquetes</span>
                </a>
            </li>
            <li class="nav-item">
                <a href="<?php echo $baseUrl; ?>/repartidor/weekly_deliveries.php" class="nav-link sidebar-link <?php echo $active('/repartidor/weekly_deliveries.php'); ?>">
                    <div class="sidebar-icon">
                        <i class="material-icons">date_range</i>
                    </div>
                    <span class="nav-text">Entregas semanales</span>
                </a>
            </li>
        <?php elseif ($role === 'cliente'): ?>
            <li class="nav-item">
                <a href="<?php echo $baseUrl; ?>/cliente/dashboard.php" class="nav-link sidebar-link <?php echo $active('/cliente/dashboard.php'); ?>">
                    <div class="sidebar-icon">
                        <i class="material-icons">shopping_cart</i>
                    </div>
                    <span class="nav-text">Mi envío</span>
                </a>
            </li>
        <?php endif; ?>
    </ul>
    <hr class="text-white-50">
    <div class="mt-auto">
        <a href="<?php echo $baseUrl; ?>/logout.php" class="btn btn-outline-light w-100 btn-logout">Cerrar sesión</a>
        
        <div class="mt-4 pt-3 border-top border-white-50 user-info-section">
            <small class="opacity-75 d-block mb-2">Conectado como</small>
            <div class="fw-semibold mt-2 user-name animate-on-load"><?php echo esc($user['name'] ?? 'Invitado'); ?></div>
            <span class="badge bg-light text-primary badge-role mt-2 d-inline-block animate-on-load"><?php echo esc($role); ?></span>
        </div>
    </div>
</div>

<style>
    /* Estilos del Sidebar */
    .sidebar-logo-icon {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        width: 40px;
        height: 40px;
        background: rgba(255, 255, 255, 0.2);
        border-radius: 50%;
        transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
    }

    .logo-brand:hover .sidebar-logo-icon {
        background: rgba(255, 255, 255, 0.3);
        transform: scale(1.1) rotate(-5deg);
    }

    .sidebar-logo-icon i {
        font-size: 24px;
        transition: transform 0.3s cubic-bezier(0.4, 0, 0.2, 1);
    }

    .logo-brand:hover .sidebar-logo-icon i {
        transform: rotate(360deg);
    }

    /* Estilos de links del sidebar */
    .sidebar-link {
        display: flex !important;
        align-items: center;
        padding: 0.75rem 1rem !important;
        margin-bottom: 0.5rem;
        border-radius: 8px;
        transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        border-left: 4px solid transparent !important;
        background: transparent !important;
        position: relative;
        overflow: hidden;
    }

    .sidebar-link::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(255, 255, 255, 0.1);
        transform: scaleX(0);
        transform-origin: left;
        transition: transform 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        z-index: -1;
    }

    .sidebar-link:hover::before {
        transform: scaleX(1);
    }

    .sidebar-link:hover,
    .sidebar-link.active {
        background: rgba(255, 255, 255, 0.15) !important;
        border-left: 4px solid var(--ms-yellow) !important;
        padding-left: calc(1rem - 4px) !important;
    }

    /* Icono del sidebar */
    .sidebar-icon {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        width: 32px;
        height: 32px;
        border-radius: 6px;
        background: rgba(255, 255, 255, 0.1);
        transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        flex-shrink: 0;
    }

    .sidebar-link:hover .sidebar-icon,
    .sidebar-link.active .sidebar-icon {
        background: rgba(255, 255, 255, 0.25);
        transform: scale(1.15);
    }

    .sidebar-icon i {
        font-size: 20px;
        transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
    }

    .sidebar-link:hover .sidebar-icon i,
    .sidebar-link.active .sidebar-icon i {
        transform: scale(1.2);
    }

    .sidebar-link {
        color: rgba(255, 255, 255, 0.85) !important;
    }

    .sidebar-link:hover,
    .sidebar-link.active {
        color: #fff !important;
    }

    .nav-text {
        transition: all 0.3s ease;
        letter-spacing: 0.3px;
    }

    /* Botón de cerrar sesión */
    .btn-logout {
        transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        border: 2px solid rgba(255, 255, 255, 0.3);
        font-weight: 600;
    }

    .btn-logout:hover {
        background: rgba(216, 59, 1, 0.8) !important;
        border-color: var(--ms-red) !important;
        transform: translateY(-2px);
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.3);
        color: #fff !important;
    }

    .btn-logout:active {
        transform: translateY(0);
    }

    /* Badge de rol mejorado */
    .badge-role {
        display: inline-block;
        padding: 0.35rem 0.75rem !important;
        font-weight: 600;
        border-radius: 20px;
        text-transform: uppercase;
        font-size: 0.7rem;
        letter-spacing: 0.05em;
        animation: badgePulse 2s ease-in-out infinite;
    }

    @keyframes badgePulse {
        0%, 100% { opacity: 1; }
        50% { opacity: 0.8; }
    }

    /* Animación de entrada para elementos del sidebar */
    .nav-item {
        animation: slideInLeft 0.5s ease-out backwards;
    }

    .nav-item:nth-child(1) { animation-delay: 0.1s; }
    .nav-item:nth-child(2) { animation-delay: 0.15s; }
    .nav-item:nth-child(3) { animation-delay: 0.2s; }
    .nav-item:nth-child(4) { animation-delay: 0.25s; }

    @keyframes slideInLeft {
        from {
            opacity: 0;
            transform: translateX(-20px);
        }
        to {
            opacity: 1;
            transform: translateX(0);
        }
    }

    /* Efecto de ripple al hacer click */
    .sidebar-link {
        position: relative;
    }

    .sidebar-link::after {
        content: '';
        position: absolute;
        top: 50%;
        left: 50%;
        width: 0;
        height: 0;
        background: rgba(255, 255, 255, 0.3);
        border-radius: 50%;
        transform: translate(-50%, -50%);
        transition: width 0.6s, height 0.6s;
        pointer-events: none;
    }

    /* Ajustes para mejor visual */
    .nav-pills .nav-link {
        padding: 0 !important;
    }

    /* Animación de carga de página */
    .animate-on-load {
        animation: fadeInUp 0.6s ease-out 0.5s both;
    }

    .user-name {
        color: rgba(255, 255, 255, 0.95);
        transition: all 0.3s ease;
    }

    .user-name:hover {
        color: #fff;
        text-shadow: 0 0 10px rgba(255, 255, 255, 0.3);
    }

    .user-info-section {
        animation: slideUp 0.6s ease-out 0.6s both;
    }

    @keyframes slideUp {
        from {
            opacity: 0;
            transform: translateY(20px);
        }
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }

    /* Animación mejorada de entrada del logo */
    .logo-brand {
        animation: slideInDown 0.5s ease-out;
    }

    @keyframes slideInDown {
        from {
            opacity: 0;
            transform: translateY(-20px);
        }
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }

    /* Efecto de brillo en hover de iconos */
    .sidebar-icon::before {
        content: '';
        position: absolute;
        top: -50%;
        left: -50%;
        width: 200%;
        height: 200%;
        background: radial-gradient(circle, rgba(255,255,255,0.4) 0%, rgba(255,255,255,0) 70%);
        opacity: 0;
        transition: opacity 0.4s ease;
    }

    .sidebar-link:hover .sidebar-icon::before {
        opacity: 1;
    }

    .sidebar-icon {
        position: relative;
        overflow: hidden;
    }

    /* Animación de pulse en los iconos activos */
    .sidebar-link.active .sidebar-icon i {
        animation: iconPulse 2s ease-in-out infinite;
    }

    @keyframes iconPulse {
        0%, 100% {
            transform: scale(1.2);
            filter: drop-shadow(0 0 5px rgba(255, 255, 255, 0.3));
        }
        50% {
            transform: scale(1.3);
            filter: drop-shadow(0 0 10px rgba(255, 255, 255, 0.5));
        }
    }

    /* Animación de ondas para el icono del logo */
    .sidebar-logo-icon::after {
        content: '';
        position: absolute;
        top: 50%;
        left: 50%;
        width: 100%;
        height: 100%;
        background: radial-gradient(circle, rgba(255,255,255,0.4), transparent);
        border-radius: 50%;
        transform: translate(-50%, -50%) scale(0);
        opacity: 0;
        pointer-events: none;
    }

    .logo-brand:active .sidebar-logo-icon::after {
        animation: ripple 0.6s ease-out;
    }

    @keyframes ripple {
        0% {
            transform: translate(-50%, -50%) scale(0);
            opacity: 1;
        }
        100% {
            transform: translate(-50%, -50%) scale(2);
            opacity: 0;
        }
    }

    /* Badge pulse mejorado */
    .badge-role {
        animation: badgePulse 2s ease-in-out infinite, badgeGlow 2s ease-in-out infinite !important;
    }

    @keyframes badgeGlow {
        0%, 100% { 
            box-shadow: 0 0 0 0 rgba(0, 120, 212, 0.1);
        }
        50% { 
            box-shadow: 0 0 10px 2px rgba(0, 120, 212, 0.2);
        }
    }

    @media (max-width: 768px) {
        .sidebar-icon {
            width: 28px;
            height: 28px;
        }

        .sidebar-icon i {
            font-size: 18px;
        }

        .logo-brand {
            margin-bottom: 1rem !important;
        }
    }
</style>
