<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';
requireRole('admin');

$message = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $code = trim($_POST['code'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $origin = trim($_POST['origin'] ?? '');
    $destination = trim($_POST['destination'] ?? '');
    $delivery_fee = number_format((float) ($_POST['delivery_fee'] ?? 0), 2, '.', '');
    $status = $_POST['status'] ?? 'pending';
    $customer_id = $_POST['customer_id'] ?: null;

    if ($action === 'save_package' && $code && $description) {
        if (!empty($_POST['id'])) {
            $stmt = $pdo->prepare('UPDATE packages SET code = :code, description = :description, origin = :origin, destination = :destination, delivery_fee = :fee, status = :status, customer_id = :customer_id WHERE id = :id');
            $stmt->execute(['code' => $code, 'description' => $description, 'origin' => $origin, 'destination' => $destination, 'fee' => $delivery_fee, 'status' => $status, 'customer_id' => $customer_id, 'id' => $_POST['id']]);
            $message = 'Paquete actualizado.';
            echo '<script>$(document).ready(function() { setTimeout(function() { showCheckAnimation({message: "¡Paquete actualizado!", duration: 2000}); }, 300); });</script>';
        } else {
            $stmt = $pdo->prepare('INSERT INTO packages (code, description, origin, destination, delivery_fee, status, customer_id) VALUES (:code, :description, :origin, :destination, :fee, :status, :customer_id)');
            $stmt->execute(['code' => $code, 'description' => $description, 'origin' => $origin, 'destination' => $destination, 'fee' => $delivery_fee, 'status' => $status, 'customer_id' => $customer_id]);
            $message = 'Paquete creado.';
            echo '<script>$(document).ready(function() { setTimeout(function() { showCheckAnimation({message: "¡Paquete creado!", duration: 2000}); }, 300); });</script>';
        }
    }
    if ($action === 'delete_package' && !empty($_POST['id'])) {
        $stmt = $pdo->prepare('DELETE FROM packages WHERE id = :id');
        $stmt->execute(['id' => $_POST['id']]);
        $message = 'Paquete eliminado.';
    }
}

$id = $_GET['id'] ?? null;
$editPackage = null;
if ($id) {
    $stmt = $pdo->prepare('SELECT * FROM packages WHERE id = :id LIMIT 1');
    $stmt->execute(['id' => $id]);
    $editPackage = $stmt->fetch();
}

$packages = $pdo->query('SELECT p.*, u.name AS cliente, v.name AS repartidor FROM packages p LEFT JOIN users u ON p.customer_id = u.id LEFT JOIN users v ON p.assigned_to = v.id ORDER BY p.created_at DESC')->fetchAll();
$clients = $pdo->query('SELECT id, name FROM users WHERE role = "cliente" ORDER BY name')->fetchAll();
$title = 'Gestión de paquetes';
require __DIR__ . '/../includes/header.php';
?>
<div class="d-flex">
    <?php require __DIR__ . '/../includes/sidebar.php'; ?>
    <div class="flex-grow-1 p-4">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h1 class="h3 mb-1 text-primary"><i class="fas fa-boxes me-2"></i>Paquetes</h1>
                <p class="text-muted mb-0">Crea y administra envíos de forma rápida.</p>
            </div>
        </div>
        <?php if ($message): ?>
            <div class="alert alert-success"><?php echo esc($message); ?></div>
        <?php endif; ?>
        <div class="row g-4">
            <div class="col-lg-7">
                <div class="card shadow-sm">
                    <div class="card-header bg-primary text-white">
                        <h5 class="card-title mb-0"><i class="fas fa-list"></i> Listado de paquetes</h5>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-hover align-middle mb-0">
                                <thead class="table-light">
                                    <tr>
                                        <th><i class="fas fa-hashtag text-primary"></i> Código</th>
                                        <th><i class="fas fa-info-circle text-primary"></i> Estado</th>
                                        <th><i class="fas fa-user text-primary"></i> Cliente</th>
                                        <th><i class="fas fa-truck text-primary"></i> Repartidor</th>
                                        <th><i class="fas fa-dollar-sign text-primary"></i> Tarifa</th>
                                        <th><i class="fas fa-cogs text-primary"></i> Acciones</th>
                                    </tr>
                                </thead>
                                <tbody>
                                <?php foreach ($packages as $pkg): ?>
                                    <tr>
                                        <td><span class="badge bg-secondary"><?php echo esc($pkg['code']); ?></span></td>
                                        <td>
                                            <span class="badge 
                                            <?php 
                                            echo match($pkg['status']) {
                                                'recibido' => 'bg-warning',
                                                'en_transito' => 'bg-info',
                                                'entregado' => 'bg-success',
                                                default => 'bg-secondary'
                                            };
                                            ?>">
                                            <?php echo esc($pkg['status']); ?>
                                            </span>
                                        </td>
                                        <td><?php echo esc($pkg['cliente'] ?? 'N/E'); ?></td>
                                        <td><?php echo esc($pkg['repartidor'] ?? 'Sin asignar'); ?></td>
                                        <td class="text-success fw-bold">$<?php echo number_format($pkg['delivery_fee'], 2); ?></td>
                                        <td class="text-end">
                                            <a href="?id=<?php echo esc($pkg['id']); ?>" class="btn btn-sm btn-outline-primary me-1">
                                                <i class="fas fa-edit"></i> Editar
                                            </a>
                                            <form method="post" class="d-inline-block" onsubmit="return confirm('Eliminar paquete?');">
                                                <input type="hidden" name="action" value="delete_package">
                                                <input type="hidden" name="id" value="<?php echo esc($pkg['id']); ?>">
                                                <button type="submit" class="btn btn-sm btn-outline-danger">
                                                    <i class="fas fa-trash"></i> Eliminar
                                                </button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-5">
                <div class="card shadow-sm">
                    <div class="card-header bg-success text-white">
                        <h5 class="card-title mb-0"><i class="fas fa-plus-circle"></i> <?php echo $editPackage ? 'Editar paquete' : 'Nuevo paquete'; ?></h5>
                    </div>
                    <div class="card-body">
                        <form method="post">
                            <input type="hidden" name="action" value="save_package">
                            <?php if ($editPackage): ?>
                                <input type="hidden" name="id" value="<?php echo esc($editPackage['id']); ?>">
                            <?php endif; ?>
                            <div class="mb-3">
                                <label class="form-label fw-bold">Código</label>
                                <input type="text" name="code" class="form-control form-control-lg" value="<?php echo esc($editPackage['code'] ?? ''); ?>" required>
                            </div>
                            <div class="mb-3">
                                <label class="form-label fw-bold">Descripción</label>
                                <textarea name="description" class="form-control form-control-lg" rows="3" required><?php echo esc($editPackage['description'] ?? ''); ?></textarea>
                            </div>
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label class="form-label fw-bold">Origen</label>
                                    <input type="text" name="origin" class="form-control form-control-lg" value="<?php echo esc($editPackage['origin'] ?? ''); ?>" required>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="form-label fw-bold">Destino</label>
                                    <input type="text" name="destination" class="form-control form-control-lg" value="<?php echo esc($editPackage['destination'] ?? ''); ?>" required>
                                </div>
                            </div>
                            <div class="mb-3">
                                <label class="form-label fw-bold">Tarifa</label>
                                <input type="number" step="0.01" min="0" name="delivery_fee" class="form-control form-control-lg" value="<?php echo esc($editPackage['delivery_fee'] ?? '0.00'); ?>" required>
                            </div>
                            <div class="mb-3">
                                <label class="form-label fw-bold">Cliente</label>
                                <select name="customer_id" class="form-select form-select-lg">
                                    <option value="">Sin cliente</option>
                                    <?php foreach ($clients as $client): ?>
                                        <option value="<?php echo esc($client['id']); ?>" <?php if (($editPackage['customer_id'] ?? '') == $client['id']) echo 'selected'; ?>><?php echo esc($client['name']); ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="mb-3">
                                <label class="form-label fw-bold">Estado</label>
                                <select name="status" class="form-select form-select-lg">
                                    <option value="recibido" <?php if (($editPackage['status'] ?? '') === 'recibido') echo 'selected'; ?>>Recibido</option>
                                    <option value="en_transito" <?php if (($editPackage['status'] ?? '') === 'en_transito') echo 'selected'; ?>>En tránsito</option>
                                    <option value="entregado" <?php if (($editPackage['status'] ?? '') === 'entregado') echo 'selected'; ?>>Entregado</option>
                                </select>
                            </div>
                            <button class="btn btn-primary btn-lg w-100" type="submit">
                                <i class="fas fa-save me-2"></i>Guardar paquete
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php require __DIR__ . '/../includes/footer.php';
