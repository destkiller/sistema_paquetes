<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';
requireRole('admin');

$userCount = getUserCount($pdo);
$packageCount = getPackageCount($pdo);
$assignedCount = getAssignedCount($pdo);
$totalRevenue = getTotalRevenue($pdo);

$stmt = $pdo->query('SELECT p.*, u.name AS repartidor, c.name AS cliente FROM packages p LEFT JOIN users u ON p.assigned_to = u.id LEFT JOIN users c ON p.customer_id = c.id ORDER BY p.created_at DESC LIMIT 5');
$recentPackages = $stmt->fetchAll();

$title = 'Dashboard admin';
require __DIR__ . '/../includes/header.php';
?>
<div class="d-flex">
    <?php require __DIR__ . '/../includes/sidebar.php'; ?>
    <div class="flex-grow-1 p-4">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h1 class="h3 mb-1 text-primary"><i class="fas fa-chart-line me-2"></i>Panel administrativo</h1>
                <p class="text-muted mb-0">Resumen de entregas, usuarios y ganancias.</p>
            </div>
        </div>
        <div class="row g-3 mb-4">
            <div class="col-md-3">
                <div class="card shadow-sm border-primary">
                    <div class="card-body text-center">
                        <i class="fas fa-users fa-2x text-primary mb-2"></i>
                        <h6 class="text-uppercase text-muted">Usuarios</h6>
                        <h2 class="text-primary"><?php echo esc($userCount); ?></h2>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card shadow-sm border-info">
                    <div class="card-body text-center">
                        <i class="fas fa-box fa-2x text-info mb-2"></i>
                        <h6 class="text-uppercase text-muted">Paquetes</h6>
                        <h2 class="text-info"><?php echo esc($packageCount); ?></h2>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card shadow-sm border-warning">
                    <div class="card-body text-center">
                        <i class="fas fa-truck fa-2x text-warning mb-2"></i>
                        <h6 class="text-uppercase text-muted">Asignados</h6>
                        <h2 class="text-warning"><?php echo esc($assignedCount); ?></h2>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card shadow-sm border-success">
                    <div class="card-body text-center">
                        <i class="fas fa-dollar-sign fa-2x text-success mb-2"></i>
                        <h6 class="text-uppercase text-muted">Ganancias</h6>
                        <h2 class="text-success">$<?php echo number_format($totalRevenue, 2); ?></h2>
                    </div>
                </div>
            </div>
        </div>
        <div class="card shadow-sm">
            <div class="card-header bg-primary text-white">
                <h5 class="card-title mb-0"><i class="fas fa-clock"></i> Últimos paquetes</h5>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0">
                        <thead class="table-light">
                            <tr>
                                <th><i class="fas fa-hashtag text-primary"></i> Código</th>
                                <th><i class="fas fa-user text-primary"></i> Cliente</th>
                                <th><i class="fas fa-truck text-primary"></i> Repartidor</th>
                                <th><i class="fas fa-map-marker text-primary"></i> Destino</th>
                                <th><i class="fas fa-info-circle text-primary"></i> Estado</th>
                                <th><i class="fas fa-dollar-sign text-primary"></i> Tarifa</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php foreach ($recentPackages as $pkg): ?>
                            <tr>
                                <td><span class="badge bg-secondary"><?php echo esc($pkg['code']); ?></span></td>
                                <td><?php echo esc($pkg['cliente'] ?? 'N/E'); ?></td>
                                <td><?php echo esc($pkg['repartidor'] ?? 'Sin asignar'); ?></td>
                                <td><?php echo esc($pkg['destination']); ?></td>
                                <td>
                                    <?php
                                    $statusClass = match($pkg['status']) {
                                        'recibido' => 'bg-warning',
                                        'en_transito' => 'bg-info',
                                        'entregado' => 'bg-success',
                                        default => 'bg-secondary'
                                    };
                                    ?>
                                    <span class="badge <?php echo $statusClass; ?>"><?php echo esc($pkg['status']); ?></span>
                                </td>
                                <td class="text-success fw-bold">$<?php echo number_format($pkg['delivery_fee'], 2); ?></td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php require __DIR__ . '/../includes/footer.php';
