<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';
requireRole('admin');

$message = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    if ($action === 'assign_package' && !empty($_POST['package_id']) && !empty($_POST['repartidor_id'])) {
        $stmt = $pdo->prepare('UPDATE packages SET assigned_to = :repartidor, status = "en_transito" WHERE id = :pkg');
        $stmt->execute(['repartidor' => $_POST['repartidor_id'], 'pkg' => $_POST['package_id']]);
        $message = 'Paquete asignado al repartidor.';
        echo '<script>$(document).ready(function() { setTimeout(function() { showCheckAnimation({message: "¡Paquete asignado!", duration: 2000, type: "toast"}); }, 300); });</script>';
    }
    if ($action === 'mark_delivered' && !empty($_POST['package_id'])) {
        $stmt = $pdo->prepare('UPDATE packages SET status = "entregado" WHERE id = :pkg');
        $stmt->execute(['pkg' => $_POST['package_id']]);
        $message = 'Paquete marcado como entregado.';
        echo '<script>$(document).ready(function() { setTimeout(function() { showCheckAnimation({message: "¡Paquete entregado!", duration: 2000, type: "toast"}); }, 300); });</script>';
    }
}

$repartidores = $pdo->query('SELECT id, name FROM users WHERE role = "repartidor" ORDER BY name')->fetchAll();
$packages = $pdo->query('SELECT p.*, u.name AS cliente, v.name AS repartidor FROM packages p LEFT JOIN users u ON p.customer_id = u.id LEFT JOIN users v ON p.assigned_to = v.id ORDER BY p.created_at DESC')->fetchAll();
$title = 'Asignaciones';
require __DIR__ . '/../includes/header.php';
?>
<div class="d-flex">
    <?php require __DIR__ . '/../includes/sidebar.php'; ?>
    <div class="flex-grow-1 p-4">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h1 class="h3 mb-1 text-primary"><i class="fas fa-user-check me-2"></i>Asignar entregas</h1>
                <p class="text-muted mb-0">Selecciona paquetes y reparte las entregas entre repartidores.</p>
            </div>
        </div>
        <?php if ($message): ?>
            <div class="alert alert-success"><?php echo esc($message); ?></div>
        <?php endif; ?>
        <div class="card shadow-sm mb-4">
            <div class="card-header bg-info text-white">
                <h5 class="card-title mb-0"><i class="fas fa-handshake"></i> Asignar paquete</h5>
            </div>
            <div class="card-body">
                <form method="post" class="row g-3 align-items-end">
                    <input type="hidden" name="action" value="assign_package">
                    <div class="col-md-5">
                        <label class="form-label fw-bold">Paquete</label>
                        <select name="package_id" class="form-select form-select-lg" required>
                            <option value="">Seleccione un paquete</option>
                            <?php foreach ($packages as $pkg): if ($pkg['status'] === 'entregado') continue; ?>
                                <option value="<?php echo esc($pkg['id']); ?>"><?php echo esc($pkg['code'] . ' / ' . $pkg['destination'] . ' / ' . $pkg['status']); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-md-5">
                        <label class="form-label fw-bold">Repartidor</label>
                        <select name="repartidor_id" class="form-select form-select-lg" required>
                            <option value="">Seleccione un repartidor</option>
                            <?php foreach ($repartidores as $r): ?>
                                <option value="<?php echo esc($r['id']); ?>"><?php echo esc($r['name']); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-md-2 d-grid">
                        <button class="btn btn-primary btn-lg" type="submit">
                            <i class="fas fa-paper-plane me-2"></i>Asignar
                        </button>
                    </div>
                </form>
            </div>
        </div>
        <div class="card shadow-sm">
            <div class="card-header bg-primary text-white">
                <h5 class="card-title mb-0"><i class="fas fa-list"></i> Estado de paquetes</h5>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0">
                        <thead class="table-light">
                            <tr>
                                <th><i class="fas fa-hashtag text-primary"></i> Código</th>
                                <th><i class="fas fa-info-circle text-primary"></i> Estado</th>
                                <th><i class="fas fa-truck text-primary"></i> Repartidor</th>
                                <th><i class="fas fa-user text-primary"></i> Cliente</th>
                                <th><i class="fas fa-dollar-sign text-primary"></i> Tarifa</th>
                                <th><i class="fas fa-cogs text-primary"></i> Acciones</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php foreach ($packages as $pkg): ?>
                            <tr>
                                <td><span class="badge bg-secondary"><?php echo esc($pkg['code']); ?></span></td>
                                <td>
                                    <span class="badge 
                                    <?php 
                                    echo match($pkg['status']) {
                                        'recibido' => 'bg-warning',
                                        'en_transito' => 'bg-info',
                                        'entregado' => 'bg-success',
                                        default => 'bg-secondary'
                                    };
                                    ?>">
                                    <?php echo esc($pkg['status']); ?>
                                    </span>
                                </td>
                                <td><?php echo esc($pkg['repartidor'] ?? 'Sin asignar'); ?></td>
                                <td><?php echo esc($pkg['cliente'] ?? 'N/E'); ?></td>
                                <td class="text-success fw-bold">$<?php echo number_format($pkg['delivery_fee'], 2); ?></td>
                                <td class="text-end">
                                    <?php if ($pkg['status'] !== 'entregado' && $pkg['assigned_to']): ?>
                                        <form method="post" class="d-inline-block">
                                            <input type="hidden" name="action" value="mark_delivered">
                                            <input type="hidden" name="package_id" value="<?php echo esc($pkg['id']); ?>">
                                            <button type="submit" class="btn btn-sm btn-success">
                                                <i class="fas fa-check"></i> Entregar
                                            </button>
                                        </form>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php require __DIR__ . '/../includes/footer.php';
