<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';
requireRole('admin');

header('Content-Type: application/json');

$userId = $_GET['id'] ?? null;
if (!$userId) {
    echo json_encode(['error' => 'Usuario no especificado']);
    exit;
}

// Get user data
$stmt = $pdo->prepare('SELECT id, name, email, role, created_at FROM users WHERE id = :id LIMIT 1');
$stmt->execute(['id' => $userId]);
$user = $stmt->fetch();

if (!$user) {
    echo json_encode(['error' => 'Usuario no encontrado']);
    exit;
}

// Get deliveries for this user (if repartidor)
$deliveries = [];
if ($user['role'] === 'repartidor') {
    $stmt = $pdo->prepare('
        SELECT p.*, u.name AS cliente 
        FROM packages p 
        LEFT JOIN users u ON p.customer_id = u.id 
        WHERE p.assigned_to = :user_id 
        ORDER BY p.updated_at DESC 
        LIMIT 50
    ');
    $stmt->execute(['user_id' => $userId]);
    $deliveries = $stmt->fetchAll();
}

// Get packages created by user (if cliente or admin)
$packages = [];
if (in_array($user['role'], ['cliente', 'admin'])) {
    $stmt = $pdo->prepare('
        SELECT p.*, v.name AS repartidor 
        FROM packages p 
        LEFT JOIN users v ON p.assigned_to = v.id 
        WHERE p.customer_id = :user_id 
        ORDER BY p.created_at DESC 
        LIMIT 50
    ');
    $stmt->execute(['user_id' => $userId]);
    $packages = $stmt->fetchAll();
}

// Get statistics
$stats = [
    'total_packages' => 0,
    'delivered_packages' => 0,
    'in_transit_packages' => 0,
    'total_revenue' => 0
];

if ($user['role'] === 'repartidor') {
    $stmt = $pdo->prepare('
        SELECT 
            COUNT(*) as total,
            SUM(CASE WHEN status = "entregado" THEN 1 ELSE 0 END) as delivered,
            SUM(CASE WHEN status = "en_transito" THEN 1 ELSE 0 END) as in_transit,
            IFNULL(SUM(CASE WHEN status = "entregado" THEN delivery_fee ELSE 0 END), 0) as revenue
        FROM packages 
        WHERE assigned_to = :user_id
    ');
    $stmt->execute(['user_id' => $userId]);
    $result = $stmt->fetch();
    $stats = [
        'total_packages' => (int)$result['total'],
        'delivered_packages' => (int)($result['delivered'] ?? 0),
        'in_transit_packages' => (int)($result['in_transit'] ?? 0),
        'total_revenue' => (float)$result['revenue']
    ];
}

echo json_encode([
    'user' => $user,
    'deliveries' => $deliveries,
    'packages' => $packages,
    'stats' => $stats
]);
?>
