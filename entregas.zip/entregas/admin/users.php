<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';
requireRole('admin');

$message = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $name = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $role = $_POST['role'] ?? 'cliente';
    $password = trim($_POST['password'] ?? '');

    if ($action === 'save_user' && $name && $email) {
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $message = 'Correo inválido.';
        } else {
            // Check if email already exists (excluding current user when editing)
            $emailCheckQuery = 'SELECT id FROM users WHERE email = :email';
            $emailCheckParams = ['email' => $email];
            if (!empty($_POST['id'])) {
                $emailCheckQuery .= ' AND id != :id';
                $emailCheckParams['id'] = $_POST['id'];
            }
            $stmt = $pdo->prepare($emailCheckQuery);
            $stmt->execute($emailCheckParams);
            if ($stmt->fetch()) {
                $message = 'Este correo ya está registrado.';
            } else {
                if (!empty($_POST['id'])) {
                    // Editing existing user
                    $stmt = $pdo->prepare('UPDATE users SET name = :name, email = :email, role = :role WHERE id = :id');
                    $stmt->execute(['name' => $name, 'email' => $email, 'role' => $role, 'id' => $_POST['id']]);
                    if ($password) {
                        $hash = password_hash($password, PASSWORD_DEFAULT);
                        $stmt = $pdo->prepare('UPDATE users SET password = :password WHERE id = :id');
                        $stmt->execute(['password' => $hash, 'id' => $_POST['id']]);
                    }
                    $message = 'Usuario actualizado correctamente.';
                    echo '<script>$(document).ready(function() { setTimeout(function() { showCheckAnimation({message: "¡Usuario actualizado!", duration: 2000}); }, 300); });</script>';
                } else {
                    // Creating new user
                    if (!$password) {
                        $message = 'La contraseña es requerida para nuevos usuarios.';
                    } else {
                        $hash = password_hash($password, PASSWORD_DEFAULT);
                        $stmt = $pdo->prepare('INSERT INTO users (name, email, password, role) VALUES (:name, :email, :password, :role)');
                        $stmt->execute(['name' => $name, 'email' => $email, 'password' => $hash, 'role' => $role]);
                        $message = 'Usuario creado correctamente.';
                        echo '<script>$(document).ready(function() { setTimeout(function() { showCheckAnimation({message: "¡Usuario creado!", duration: 2000}); }, 300); });</script>';
                    }
                }
            }
        }
    }
    if ($action === 'delete_user' && !empty($_POST['id'])) {
        $stmt = $pdo->prepare('DELETE FROM users WHERE id = :id');
        $stmt->execute(['id' => $_POST['id']]);
        $message = 'Usuario eliminado.';
    }
}

$id = $_GET['id'] ?? null;
$editUser = null;
if ($id) {
    $stmt = $pdo->prepare('SELECT * FROM users WHERE id = :id LIMIT 1');
    $stmt->execute(['id' => $id]);
    $editUser = $stmt->fetch();
}

$users = $pdo->query('SELECT * FROM users ORDER BY created_at DESC')->fetchAll();
$title = 'Gestión de usuarios';
require __DIR__ . '/../includes/header.php';
?>
<div class="d-flex">
    <?php require __DIR__ . '/../includes/sidebar.php'; ?>
    <div class="flex-grow-1 p-4">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h1 class="h3 mb-1 text-primary"><i class="fas fa-users-cog me-2"></i>Usuarios</h1>
                <p class="text-muted mb-0">Administra repartidores y clientes.</p>
            </div>
            <div>
                <a href="users.php" class="btn btn-success">
                    <i class="fas fa-user-plus me-2"></i>Nuevo Usuario
                </a>
            </div>
        </div>
        <?php if ($message): ?>
            <div class="alert alert-success"><?php echo esc($message); ?></div>
        <?php endif; ?>
        <div class="row g-4">
            <div class="col-lg-7">
                <div class="card shadow-sm">
                    <div class="card-header bg-primary text-white">
                        <h5 class="card-title mb-0"><i class="fas fa-list"></i> Listado de usuarios</h5>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-hover align-middle mb-0">
                                <thead class="table-light">
                                    <tr>
                                        <th><i class="fas fa-user text-primary"></i> Nombre</th>
                                        <th><i class="fas fa-envelope text-primary"></i> Email</th>
                                        <th><i class="fas fa-user-tag text-primary"></i> Rol</th>
                                        <th><i class="fas fa-calendar-plus text-primary"></i> Creado</th>
                                        <th><i class="fas fa-cogs text-primary"></i> Acciones</th>
                                    </tr>
                                </thead>
                                <tbody>
                                <?php foreach ($users as $user): ?>
                                    <tr>
                                        <td>
                                            <a href="detail_user.php?id=<?php echo esc($user['id']); ?>" class="text-decoration-none text-primary fw-bold">
                                                <i class="fas fa-user-circle me-1"></i><?php echo esc($user['name']); ?>
                                            </a>
                                        </td>
                                        <td><?php echo esc($user['email']); ?></td>
                                        <td>
                                            <span class="badge 
                                            <?php 
                                            echo match($user['role']) {
                                                'admin' => 'bg-danger',
                                                'repartidor' => 'bg-info',
                                                'cliente' => 'bg-success',
                                                default => 'bg-secondary'
                                            };
                                            ?>">
                                            <?php echo esc($user['role']); ?>
                                            </span>
                                        </td>
                                        <td><?php echo date('d/m/Y', strtotime($user['created_at'])); ?></td>
                                        <td class="text-end">
                                            <a href="?id=<?php echo esc($user['id']); ?>" class="btn btn-sm btn-outline-primary me-1">
                                                <i class="fas fa-edit"></i> Editar
                                            </a>
                                            <form method="post" class="d-inline-block" onsubmit="return confirm('Eliminar usuario?');">
                                                <input type="hidden" name="action" value="delete_user">
                                                <input type="hidden" name="id" value="<?php echo esc($user['id']); ?>">
                                                <button type="submit" class="btn btn-sm btn-outline-danger">
                                                    <i class="fas fa-trash"></i> Eliminar
                                                </button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-5">
                <div class="card shadow-sm">
                    <div class="card-header bg-warning text-dark d-flex justify-content-between align-items-center">
                        <h5 class="card-title mb-0"><i class="fas fa-user-plus"></i> <?php echo $editUser ? 'Editar usuario' : 'Nuevo usuario'; ?></h5>
                        <?php if ($editUser): ?>
                            <a href="users.php" class="btn btn-sm btn-outline-secondary">
                                <i class="fas fa-plus"></i> Nuevo
                            </a>
                        <?php endif; ?>
                    </div>
                    <div class="card-body">
                        <form method="post" class="needs-validation" novalidate onsubmit="<?php echo $editUser ? '' : 'return confirm(\'¿Crear nuevo usuario?\');'; ?>">
                            <input type="hidden" name="action" value="save_user">
                            <?php if ($editUser): ?>
                                <input type="hidden" name="id" value="<?php echo esc($editUser['id']); ?>">
                            <?php endif; ?>
                            <div class="mb-3">
                                <label class="form-label fw-bold">Nombre</label>
                                <input type="text" name="name" class="form-control form-control-lg" value="<?php echo esc($editUser['name'] ?? ''); ?>" required minlength="2" maxlength="100">
                                <div class="invalid-feedback">El nombre debe tener al menos 2 caracteres.</div>
                            </div>
                            <div class="mb-3">
                                <label class="form-label fw-bold">Email</label>
                                <input type="email" name="email" class="form-control form-control-lg" value="<?php echo esc($editUser['email'] ?? ''); ?>" required>
                                <div class="invalid-feedback">Ingrese un correo electrónico válido.</div>
                            </div>
                            <div class="mb-3">
                                <label class="form-label fw-bold">Rol</label>
                                <select name="role" class="form-select form-select-lg">
                                    <option value="admin" <?php if (($editUser['role'] ?? '') === 'admin') echo 'selected'; ?>>Admin</option>
                                    <option value="repartidor" <?php if (($editUser['role'] ?? '') === 'repartidor') echo 'selected'; ?>>Repartidor</option>
                                    <option value="cliente" <?php if (($editUser['role'] ?? '') === 'cliente') echo 'selected'; ?>>Cliente</option>
                                </select>
                            </div>
                            <div class="mb-3">
                                <label class="form-label fw-bold">Contraseña</label>
                                <input type="password" name="password" class="form-control form-control-lg" value="" <?php echo $editUser ? '' : 'required minlength="6"'; ?>>
                                <div class="form-text">
                                    <?php if ($editUser): ?>
                                        Dejar vacío para mantener la contraseña actual.
                                    <?php else: ?>
                                        Contraseña requerida para nuevos usuarios (mínimo 6 caracteres).
                                    <?php endif; ?>
                                </div>
                                <div class="invalid-feedback">La contraseña debe tener al menos 6 caracteres.</div>
                            </div>
                            <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                                <?php if (!$editUser): ?>
                                    <button type="reset" class="btn btn-outline-secondary">
                                        <i class="fas fa-eraser me-2"></i>Limpiar
                                    </button>
                                <?php endif; ?>
                                <button class="btn btn-primary" type="submit">
                                    <i class="fas fa-save me-2"></i><?php echo $editUser ? 'Actualizar' : 'Crear Usuario'; ?>
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php require __DIR__ . '/../includes/footer.php';
