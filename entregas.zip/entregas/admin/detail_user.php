<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';
requireRole('admin');

$userId = $_GET['id'] ?? null;
if (!$userId) {
    redirect('/entregas/admin/users.php');
}

$stmt = $pdo->prepare('SELECT * FROM users WHERE id = :id LIMIT 1');
$stmt->execute(['id' => $userId]);
$user = $stmt->fetch();

if (!$user) {
    redirect('/entregas/admin/users.php');
}

// Get statistics
$stats = [
    'total_packages' => 0,
    'delivered_packages' => 0,
    'received_packages' => 0,
    'in_transit_packages' => 0,
    'total_revenue' => 0
];

$packages = [];

// If repartidor - get assigned packages
if ($user['role'] === 'repartidor') {
    $stmt = $pdo->prepare('
        SELECT 
            COUNT(*) as total,
            SUM(CASE WHEN status = "entregado" THEN 1 ELSE 0 END) as delivered,
            SUM(CASE WHEN status = "recibido" THEN 1 ELSE 0 END) as received,
            SUM(CASE WHEN status = "en_transito" THEN 1 ELSE 0 END) as in_transit,
            IFNULL(SUM(CASE WHEN status = "entregado" THEN delivery_fee ELSE 0 END), 0) as revenue
        FROM packages 
        WHERE assigned_to = :user_id
    ');
    $stmt->execute(['user_id' => $userId]);
    $result = $stmt->fetch();
    $stats = [
        'total_packages' => (int)$result['total'],
        'delivered_packages' => (int)($result['delivered'] ?? 0),
        'received_packages' => (int)($result['received'] ?? 0),
        'in_transit_packages' => (int)($result['in_transit'] ?? 0),
        'total_revenue' => (float)$result['revenue']
    ];
    
    $stmt = $pdo->prepare('
        SELECT p.*, u.name AS cliente 
        FROM packages p 
        LEFT JOIN users u ON p.customer_id = u.id 
        WHERE p.assigned_to = :user_id 
        ORDER BY p.updated_at DESC
    ');
    $stmt->execute(['user_id' => $userId]);
    $packages = $stmt->fetchAll();
}
// If cliente - get created packages
elseif ($user['role'] === 'cliente') {
    $stmt = $pdo->prepare('
        SELECT p.*, v.name AS repartidor 
        FROM packages p 
        LEFT JOIN users v ON p.assigned_to = v.id 
        WHERE p.customer_id = :user_id 
        ORDER BY p.created_at DESC
    ');
    $stmt->execute(['user_id' => $userId]);
    $packages = $stmt->fetchAll();
}

$title = 'Detalle del Usuario - ' . $user['name'];
require __DIR__ . '/../includes/header.php';
?>
<div class="d-flex">
    <?php require __DIR__ . '/../includes/sidebar.php'; ?>
    <div class="flex-grow-1 p-4">
        <!-- Header con navegación -->
        <div class="mb-4">
            <a href="users.php" class="btn btn-outline-secondary me-2">
                <i class="fas fa-arrow-left me-2"></i>Volver a Usuarios
            </a>
        </div>

        <!-- Tarjeta de Usuario -->
        <div class="row g-4">
            <div class="col-lg-4">
                <div class="card shadow-sm">
                    <div class="card-body text-center py-5">
                        <div class="mb-3">
                            <div style="width: 100px; height: 100px; background: linear-gradient(135deg, #0078D4 0%, #106EBE 100%); border-radius: 50%; display: flex; align-items: center; justify-content: center; color: white; font-size: 48px; margin: 0 auto; box-shadow: 0 2px 8px rgba(0, 120, 212, 0.4);">
                                <i class="fas fa-user"></i>
                            </div>
                        </div>
                        <h3 class="card-title mb-1"><?php echo esc($user['name']); ?></h3>
                        <span class="badge 
                        <?php 
                        echo match($user['role']) {
                            'admin' => 'bg-danger',
                            'repartidor' => 'bg-info',
                            'cliente' => 'bg-success',
                            default => 'bg-secondary'
                        };
                        ?> mb-3 d-inline-block">
                        <?php echo strtoupper(esc($user['role'])); ?>
                        </span>
                        <p class="text-muted mb-0"><?php echo esc($user['email']); ?></p>
                    </div>
                    <div class="card-body border-top">
                        <div class="mb-3">
                            <small class="text-muted d-block mb-1"><i class="fas fa-envelope me-2 text-primary"></i>Email</small>
                            <span><?php echo esc($user['email']); ?></span>
                        </div>
                        <div class="mb-3">
                            <small class="text-muted d-block mb-1"><i class="fas fa-calendar me-2 text-primary"></i>Registrado</small>
                            <span><?php echo date('d/m/Y H:i', strtotime($user['created_at'])); ?></span>
                        </div>
                        <div>
                            <small class="text-muted d-block mb-1"><i class="fas fa-id-badge me-2 text-primary"></i>ID</small>
                            <span>#<?php echo esc($user['id']); ?></span>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-lg-8">
                <!-- Estadísticas -->
                <?php if ($user['role'] === 'repartidor' && $stats['total_packages'] > 0): ?>
                <div class="card shadow-sm mb-4">
                    <div class="card-header bg-primary text-white">
                        <h5 class="card-title mb-0"><i class="fas fa-chart-bar me-2"></i>Estadísticas</h5>
                    </div>
                    <div class="card-body">
                        <div class="row g-3">
                            <div class="col-6 col-md-3">
                                <div class="stat-box p-3 bg-light rounded text-center">
                                    <div class="stat-value text-primary fw-bold fs-4"><?php echo $stats['total_packages']; ?></div>
                                    <small class="text-muted">Total Asignado</small>
                                </div>
                            </div>
                            <div class="col-6 col-md-3">
                                <div class="stat-box p-3 bg-light rounded text-center">
                                    <div class="stat-value text-success fw-bold fs-4"><?php echo $stats['delivered_packages']; ?></div>
                                    <small class="text-muted">Entregados</small>
                                </div>
                            </div>
                            <div class="col-6 col-md-3">
                                <div class="stat-box p-3 bg-light rounded text-center">
                                    <div class="stat-value text-info fw-bold fs-4"><?php echo $stats['in_transit_packages']; ?></div>
                                    <small class="text-muted">En Tránsito</small>
                                </div>
                            </div>
                            <div class="col-6 col-md-3">
                                <div class="stat-box p-3 bg-light rounded text-center">
                                    <div class="stat-value text-warning fw-bold fs-4"><?php echo $stats['received_packages']; ?></div>
                                    <small class="text-muted">Recibidos</small>
                                </div>
                            </div>
                        </div>
                        <div class="row mt-3">
                            <div class="col-12">
                                <div class="stat-box p-3 bg-light rounded text-center border-left-success">
                                    <small class="text-muted d-block mb-1">Ingresos Totales</small>
                                    <div class="text-success fw-bold fs-3">$<?php echo number_format($stats['total_revenue'], 2); ?></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endif; ?>

                <!-- Listado de Paquetes -->
                <div class="card shadow-sm">
                    <div class="card-header bg-success text-white">
                        <h5 class="card-title mb-0">
                            <i class="fas fa-box me-2"></i>
                            <?php echo $user['role'] === 'repartidor' ? 'Paquetes Asignados' : 'Paquetes'; ?>
                        </h5>
                    </div>
                    <div class="card-body">
                        <?php if (count($packages) > 0): ?>
                        <!-- Tabla de Paquetes con DataTable -->
                        <div class="table-responsive">
                            <table class="table table-striped table-hover align-middle" id="packagesDataTable">
                                <thead class="table-light">
                                    <tr>
                                        <th><i class="fas fa-hashtag text-primary"></i> Código</th>
                                        <th><i class="fas fa-map-marker text-primary"></i> Destino</th>
                                        <?php if ($user['role'] === 'repartidor'): ?>
                                            <th><i class="fas fa-user text-primary"></i> Cliente</th>
                                        <?php else: ?>
                                            <th><i class="fas fa-truck text-primary"></i> Repartidor</th>
                                        <?php endif; ?>
                                        <th><i class="fas fa-info-circle text-primary"></i> Estado</th>
                                        <th><i class="fas fa-calendar text-primary"></i> Fecha</th>
                                        <th><i class="fas fa-dollar-sign text-primary"></i> Tarifa</th>
                                    </tr>
                                </thead>
                                <tbody>
                                <?php foreach ($packages as $pkg): ?>
                                    <tr class="package-row">
                                        <td><span class="badge bg-secondary"><?php echo esc($pkg['code']); ?></span></td>
                                        <td><?php echo esc($pkg['destination']); ?></td>
                                        <td>
                                            <?php 
                                            if ($user['role'] === 'repartidor') {
                                                echo esc($pkg['cliente'] ?? 'N/E');
                                            } else {
                                                echo esc($pkg['repartidor'] ?? 'Sin asignar');
                                            }
                                            ?>
                                        </td>
                                        <td>
                                            <span class="badge 
                                            <?php 
                                            echo match($pkg['status']) {
                                                'recibido' => 'bg-warning',
                                                'en_transito' => 'bg-info',
                                                'entregado' => 'bg-success',
                                                default => 'bg-secondary'
                                            };
                                            ?>">
                                            <?php echo esc($pkg['status']); ?>
                                            </span>
                                        </td>
                                        <td><?php echo date('d/m/Y', strtotime($pkg['updated_at'])); ?></td>
                                        <td class="text-success fw-bold">$<?php echo number_format($pkg['delivery_fee'], 2); ?></td>
                                    </tr>
                                <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>

                        <?php else: ?>
                        <div class="alert alert-info mb-0">
                            <i class="fas fa-info-circle me-2"></i>
                            No hay paquetes registrados para este usuario.
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
$(document).ready(function() {
    // Inicializar DataTable
    var packagesTable = $('#packagesDataTable').DataTable({
        language: {
            url: 'https://cdn.datatables.net/plug-ins/1.13.7/i18n/es-ES.json'
        },
        responsive: true,
        pageLength: 10,
        dom: '<"row"<"col-sm-12 col-md-6"l><"col-sm-12 col-md-6"f>>' +
             '<"row"<"col-sm-12"tr>>' +
             '<"row"<"col-sm-12 col-md-5"i><"col-sm-12 col-md-7"p>>',
        columnDefs: [
            {
                targets: 0,
                className: 'text-center'
            }
        ],
        order: [[4, 'desc']], // Ordenar por fecha descendente
        drawCallback: function() {
            // Aplicar animaciones después de dibujar
            $('.dataTables_paginate a, .dataTables_length select, .dataTables_filter input').addClass('btn-sm form-control form-control-sm');
        }
    });
    
    // Personalizar el estilo del filtro
    $('.dataTables_filter input').addClass('form-control form-control-sm').css('margin-left', '10px');
    $('.dataTables_filter label').addClass('d-flex align-items-center mb-0');
});
</script>

<?php require __DIR__ . '/../includes/footer.php'; ?>
